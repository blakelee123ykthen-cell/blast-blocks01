/* Offline application shell. All game code, CSS, and fonts are in index.html. */
const CACHE = 'blast-blocks-cosmic-v3';
const SHELL = ['/', '/index.html', '/icon.svg', '/manifest.webmanifest', '/images/cosmic-challenge.jpg'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('blast-blocks-cosmic-') && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;
  // APKs are optional native build artifacts, not part of the offline web shell.
  // Never cache a stale availability response or a large/partial APK download.
  if (new URL(request.url).pathname.startsWith('/downloads/')) return;
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).then(response => {
      if (response.ok) { const copy = response.clone(); event.waitUntil(caches.open(CACHE).then(cache => cache.put('/index.html', copy))); }
      return response;
    }).catch(() => caches.match('/index.html').then(response => response || new Response('Open the game online once to make offline play available.', { status: 503, headers: { 'Content-Type': 'text/plain' } }))));
    return;
  }
  event.respondWith(caches.match(request).then(cached => cached || fetch(request).then(response => {
    if (response.ok) { const copy = response.clone(); event.waitUntil(caches.open(CACHE).then(cache => cache.put(request, copy))); }
    return response;
  })));
});
