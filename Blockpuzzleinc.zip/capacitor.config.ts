import type { CapacitorConfig } from '@capacitor/cli';
import native from './native-config.json';

const config: CapacitorConfig = {
  appId: native.appId,
  appName: native.appName,
  webDir: 'dist',
  server: { androidScheme: 'https' },
  android: { backgroundColor: '#0d101b', allowMixedContent: false },
  plugins: {
    SystemBars: { insetsHandling: 'css', style: 'DARK', hidden: false, animation: 'NONE' },
  },
};
export default config;
