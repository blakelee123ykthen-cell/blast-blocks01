# Get a real Android APK

The project includes a native Android APK builder. This editor exposes a web build tool, not an Android/Gradle execution environment, so an APK has not been compiled or attached here. The automation below must actually run successfully before there is a file to download.

## Easiest route: let GitHub build it

1. Export the complete project and upload/push it into a GitHub repository you control. Keep the hidden `.github/workflows/android-apk.yml` file. The workflow must be on the repository's default branch. Do not upload node_modules, signing keys, or secrets.
2. In that repository, open **Actions -> Build Android APK -> Run workflow**. Keep **publish_release** enabled if you want a direct APK download in Releases. This also grants that workflow permission to publish the test build to your repository.
3. Wait for the **Compile and verify the APK** job to finish successfully. The job installs Node 22, JDK 21, and Android SDK 36, checks TypeScript and gameplay tests, generates the native project, and compiles the APK.
4. Open **Releases -> Blast Blocks Android test build -> Assets -> Blast-Blocks.apk**. If you did not enable release publishing, open the completed workflow's **Artifacts -> Blast-Blocks-Android-APK**, download the ZIP, and extract the APK. GitHub artifact downloads require signing in.
5. Download/open **Blast-Blocks.apk** on your Android phone and confirm **Install**. Android may ask you to allow this browser or file manager to install unknown apps. Allow only a source you trust, keep Play Protect enabled, and turn the permission off again afterward if desired.

The native game supports Android 7.0+ with a current System WebView and works offline from its first launch. It uses the project's development ad configuration by default. This is an installable, debug-signed **test APK**, not a signed commercial release or a Google Play listing.

If your organization's policy prevents release creation, the successfully compiled APK remains in the build artifact even if the separate publish job fails. You can disable publish_release and rerun. Workflows require an eligible GitHub account, enabled Actions, network access, and available Actions minutes. No workflow has been triggered from this workspace.

## Updates and saves

Android updates require the same package ID and signing key. The workflow caches its disposable debug signing key for ordinary repeat builds, but a cache eviction can produce a different key. If Android rejects an update, do not uninstall unless you accept losing the previous game's local saves. Use a protected, stable release signing key for long-term distribution. Never reuse the debug key for a Play Store release.

Your web-browser scores and coins do not automatically transfer into a separately installed APK. Native progress is saved locally inside the Android app. Uninstalling or clearing its data removes that progress.

## Build locally instead

Install Node 22+, JDK 21+, and Android SDK Platform 36 / Build Tools 36.0.0. Set JAVA_HOME and ANDROID_HOME as needed. Android Studio can install the Java/SDK components.

Check the prerequisites without creating files: `node scripts/build-apk.mjs --check`.

Build the web assets with `npm run build`, then run `node scripts/build-apk.mjs`.

The APK builder uses the existing setup script, runs Gradle's assembleDebug task, verifies the APK signature with Android's apksigner, checks package/SDK values with aapt, and confirms that the offline game assets are inside the APK. It refuses to advertise a failed or invalid new build.

Successful outputs:

- `release-assets/Blast-Blocks.apk`: installable debug-signed Android game.
- `release-assets/Blast-Blocks.apk.sha256`: SHA-256 checksum.
- `release-assets/INSTALL-APK.txt`: phone installation instructions.
- `release-assets/apk-signature-verification.txt`: Android signature-verification output.
- `public/downloads/` and `dist/downloads/`: the real APK and its generated `apk.json` availability metadata.

Serve the workflow's **Blast-Blocks-Website-With-APK** artifact on your HTTPS hosting service to enable the in-game APK download. It is a complete deployable site with the compiled APK included. The normal web preview without a successful native build deliberately reports that no APK download is available. Nothing is automatically published to your website by this workflow.

## Commercial APK and AAB

See README.md for Android Studio's signed release APK and Android App Bundle steps, package IDs, production ad IDs, and remaining Play requirements. This workflow intentionally never pretends a debug-signed build is a Play-ready commercial release.