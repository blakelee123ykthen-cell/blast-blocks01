# Game verification and release QA

## Verification included in the project

`src/game/checks.ts` contains deterministic checks for the pure gameplay and progression systems. They run after app startup without modifying player data, and can be rerun in Settings. Failures are logged and reported visibly. `tests/game.test.ts` wraps those cases as Node tests and adds persistence and unavailable-ad checks.

Run: `npx tsc --noEmit`, then `npx tsx --test tests/*.test.ts`.

Production compilation was checked with the provided Vite build tool. The creation environment does not expose a device browser, Android SDK, physical phones, or a production ad account. The interactive/native items below must therefore be run before a commercial release rather than represented as already device-tested.

## Automated logic coverage

- 8×8 dimensions; 42 unique connected shapes.
- Single, horizontal, and vertical bounds; overlap rejection; invalid-move immutability.
- Placement points; used-piece rejection; row, column, intersection, triple and quadruple clears.
- Simultaneous line bonuses; consecutive streak multipliers; non-clear reset.
- Three-piece tray lifecycle; seeded/daily determinism; fitting-piece fairness on crowded boards.
- Game-over detection and a legal-piece exception.
- One-time revive; every shape fits its cleared 5×5 landing zone; no revive points.
- Normal offline coins/XP; serialized board/tray/RNG round trip.
- XP thresholds and cosmetic-only level unlocks.
- Exact-price purchases; free re-equips; insufficient-balance rejection; complete skin palettes.
- Daily completion counted once; claims counted once; expired/incomplete reward rejection.
- Achievement eligibility and double-claim prevention; full cosmetic/achievement catalog.
- Save/load of profile/settings/current game; malformed saves; corrupt-session fallback; persisted daily claims.
- Web ad unavailability; no simulated rewards or blocking natural-break ads.
- APK metadata validation: signature-verification flag, checksum format, package/SDK/version values, size, and fixed same-origin file path. Missing or malformed metadata cannot create a fake download.

## APK build and download QA

The editor does not expose Android/Gradle execution or GitHub credentials; the APK workflow has been added but has not been run here. See `docs/APK_DOWNLOAD.md` for the required first actual native build.

1. Run the **Build Android APK** workflow from your own repository's default branch. Confirm script syntax checks, TypeScript checks, all Node tests, web compilation, and native compilation complete successfully.
2. Verify that the builder's apksigner and aapt checks pass, that package/SDK values match native-config.json, and that the APK includes assets/public/index.html plus the original challenge image.
3. Download the artifact, extract it, and compare Blast-Blocks.apk against its SHA-256 file. If release publication was enabled, confirm the release attachment downloads the same file. Install it on a supported Android device.
4. Serve the complete **Blast-Blocks-Website-With-APK** artifact on HTTPS. Open Install on phone -> Android APK, and check version/size/package, the actual download, and installation instructions. Browser progress must not be falsely presented as transferred into the native app.
5. Without a native build, with invalid metadata, with the APK missing, with an HTML fallback response, or while offline, confirm the screen reports unavailable instead of offering a nonexistent download. Check the retry button after a successful file upload.
6. Confirm the service worker does not cache APK availability responses or large/partial APK binaries. The ordinary web shell should remain offline-ready independently.
7. Repeat a build with the same test signing key and increasing versionCode, then test an in-place update. A changed signing key must not be represented as an update that preserves local data; do not uninstall without acknowledging save loss.

## Interactive web QA — run in a device-capable browser

1. Open a fresh profile: home, score zero, 250 welcome coins, starter cosmetics.
2. Press Play: empty real board and three generated pieces. Select/tap placement and keyboard alternative.
3. Drag with mouse and one finger. Check pointer capture beyond the tray, touch lift, smooth following, valid preview, predicted line highlighting, and invalid red preview.
4. Release in bounds, on occupied cells, beyond board edges, and away from the board. Valid drops snap; invalid drops return without changing score/pieces.
5. Place the whole tray and confirm new pieces are generated only after all three are used.
6. Fill horizontal and vertical lines, then a cross and multiple parallel lines. Check highlight → short pause → burst → removal, exact bonuses, and combo behavior.
7. Play to game over. Confirm score/best/earned coins, record celebration, Home, and Play Again. No revive/ad bonus button should appear in a normal web browser.
8. Pause/resume, restart cancellation/confirmation, navigate to shop and back, and resume the unchanged saved game.
9. Purchase affordable Ice/Candy cosmetics, attempt unaffordable purchases, equip owned items repeatedly, and inspect each actual skin/theme/effect in gameplay. Effects also have working shop previews.
10. Complete/collect an achievement. Reopen/reload and verify it cannot be collected again.
11. Start the daily mission, advance its correct per-run metric, collect a reward, reload, and verify a second claim is impossible. Check UTC rollover; normal coins/XP remain earnable on an expired daily run.
12. Toggle music, sound, haptics, and reduced motion. Check all legal/privacy/settings/reset buttons. Reset confirmation must clearly warn and restore a fresh profile.
13. Close the browser after a move and after the final move. Reopen, resume, and confirm saved board/RNG/tray/rewards. The interrupted game-over record reward must settle exactly once.
14. Visit once online, wait for SW activation, switch offline, reload, and check the image, bundled fonts, all gameplay/progression, cosmetics, and achievement/daily claims. No remote game APIs should be necessary.
15. Test 320×568, 360×640, 390×844, 430×932, tablet, and desktop. Test zoom, OS text sizing, reduced-motion preference, safe-area cutouts, focus trap, Escape, and keyboard navigation.

## Native Android QA — release gate

- Generate the project with Node 22+, run Android Studio/Gradle builds, and install the debug APK.
- Test API 24/older low-memory hardware and current API 35/36 devices with current WebView. Profile a long drag/clear session; target 60 FPS where supported, observe memory/thermal behavior, and verify no detached particle/audio nodes accumulate.
- Verify phone portrait orientation and adaptive larger-screen layouts. Android 16 may ignore fixed orientation on large screens; layout must remain usable.
- Verify status/navigation-bar contrast and CSS safe areas with gesture navigation and a cutout. Hardware back must close dialogs, pause gameplay, navigate home, then exit safely.
- Background, force-stop, kill during a clear/game-over animation, reopen, and verify save recovery. Check airplane-mode first launch: native gameplay must be offline-ready immediately.
- Check native light/medium haptics and unsupported hardware; no excessive vibration.
- Validate original launcher icons at all densities, round/adaptive masks, splash behavior, and generated Play assets.

## AdMob test QA — use only demo IDs/test devices

- Ad SDK must not initialize from app launch or normal placement. No ads during active gameplay or immediately after launch.
- Exercise consent required, consent not required, refusal, privacy-options availability, offline mode, no-fill, load error, and cancellation.
- At game over, show Continue only after a rewarded ad is actually loaded. Closing before reward must not revive. A confirmed reward plus dismissal revives once, without points. The second game over has no revive offer.
- In Shop, a confirmed/dismissed optional reward grants exactly 75 coins, at most three per UTC day. Unavailable or cancelled ads grant nothing.
- Interstitials require at least three finished games, 120 seconds after launch, and a 180-second interval; only show on the game-over Home/Play Again action. Do not begin the new game before dismissal.
- Optional menu banner stays off by default, never overlays a live board, and hides before gameplay if enabled for a release.
- Verify the final merged manifest, removal of AD_ID permission if configured, accurate UMP messages, and Data Safety disclosures for all final SDKs.

## Release security and publishing checks

Run `npm audit`, resolve/assess transitive-tooling advisories, keep native/mobile ad dependencies current, and retest after updates. Keep keystores and passwords outside source control. Verify target API 36/current Play policy, signing, versionCode, 16 KB page compatibility if any native SDK bundles native libraries, target audience/content rating, contains-ads declarations, legal contact and hosted privacy policy, actual screenshots, account verification, and required closed testing. Do not advertise untested features as certified.
