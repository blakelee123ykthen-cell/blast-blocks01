# Honest Google Play store listing

## Identity

This is an original game. Artwork, logo, UI, animations, synthesized sound effects, music, and code were created for this implementation. It has no affiliation with another block-puzzle publisher. General polyomino placement mechanics are not presented as exclusive to this app.

The requested internal product name is **Block Blast Puzzle: Blast Blocks** and the main menu reads **BLOCK BLAST PUZZLE**. That full product name is 32 characters, exceeding Google Play's 30-character title limit. Use the following distinct, compliant public listing title instead, subject to your own trademark clearance.

**Title (27 characters):** Blast Blocks: Cosmic Puzzle

**Short description (72 characters):** Find your flow. Place colorful blocks, clear lines, and chase your best.

## Full description

A few blocks. A little strategy. A whole universe of possibilities.

Blast Blocks: Cosmic Puzzle is an original block puzzle game about finding your flow. Drag colorful pieces onto an 8×8 board, complete rows and columns, and make room for your next good move. There are no timers or energy meters — just you, the blocks, and the next high score.

**Easy to learn. Room to get good.**
Place three pieces at a time. Clear multiple lines together for bigger bonuses, or clear lines on consecutive moves to build your combo. The endless puzzle continues until none of your available pieces fit.

**Your little daily escape.**
A different daily challenge gives you something new to reach for. Complete the mission to earn cosmetic coins and player XP. Daily rewards can be collected once per day.

**Make your orbit your own.**
Unlock Neon, Fire, Ice, Galaxy, Candy, Chrome, Cyber, and Rainbow blocks. Discover Space, Cyber, Ocean, Sunset, and Midnight board themes, plus four colorful clear effects. Every unlock is visual only. Your strategy, not your wallet, makes the difference.

**Take your brain break anywhere.**
The main block game works offline. Your best score, coins, achievements, unlocked styles, and current board are saved on your device. It is a casual puzzle and a relaxing brain game you can play at your own pace, whether you have a minute or a little longer.

**A fair little universe.**
No coins are required to play. Optional rewarded ads may offer one continue per game or bonus cosmetic coins when inventory and consent are available. Limited interstitials appear only at natural breaks, never during active play. Normal play and rewards do not require an internet connection. Menu banners are off by default.

Find a home for a block. Make a little space. Find your flow.

This is an independent, original puzzle game and is not affiliated with another game publisher. Progress is local to your device; there is no account or cloud recovery.

## Categories and metadata

- Category: Game → Puzzle
- Appropriate tags: Casual, Puzzle, Offline, Single player (use available Play Console tags accurately).
- No claims of IQ improvement, medical benefits, guaranteed cognitive improvement, online competitions, or cloud saves.
- No keyword-stuffed title. Relevant concepts such as block puzzle, block game, casual puzzle, and offline puzzle are used naturally.
- Do not claim an affiliation with a similarly named game. Obtain title/trademark clearance before publishing.

## Assets

Run the Android setup script to generate:

- `release-assets/play-icon-512.png`: original 512×512 PNG icon.
- `release-assets/feature-graphic-1024x500.png`: original 1024×500 promotional feature graphic.
- Launcher icons at Android density sizes, including adaptive and round variants.

Capture real, current screenshots from the finished application. Required screenshot themes:

1. A real endless game with score and all three pieces visible.
2. A genuine valid placement preview.
3. A multi-line clear/combo captured during actual play.
4. Today's actual challenge and stated reward.
5. The real cosmetics shop with ownership/equipped states.
6. The real achievements screen.

Optional captions: “Find your flow”, “One move. A bigger combo.”, “A fresh daily orbit”, “All style. Never pay-to-win.” Do not fabricate boards, scores, ad-free claims, rewards, or unavailable features. Follow the current Play Console screenshot count, dimensions, and tablet requirements.

## Publishing operator must supply

Public privacy-policy URL; support email; legal/developer identity; consent messages in AdMob; accurate Data Safety disclosures for the final merged SDKs; age/content rating; contains-ads declaration; signed AAB; Play App Signing; any required closed testing; real screenshots; and region-specific legal terms.
