import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { chmod, copyFile, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const filename = 'Blast-Blocks.apk';
const buildToolsVersion = '36.0.0';
const windows = process.platform === 'win32';
const checkOnly = process.argv.includes('--check');
process.chdir(root);

function execute(command, args, { cwd = root, capture = false } = {}) {
  const result = spawnSync(command, args, {
    cwd,
    env: process.env,
    encoding: 'utf8',
    stdio: capture ? 'pipe' : 'inherit',
    shell: windows && /\.(bat|cmd)$/i.test(command),
    timeout: 20 * 60_000,
    maxBuffer: 8 * 1024 * 1024,
  });
  if (result.error) throw new Error(`${path.basename(command)}: ${result.error.message}`);
  if (result.status !== 0) {
    const detail = capture ? `\n${result.stdout ?? ''}${result.stderr ?? ''}` : '';
    throw new Error(`${path.basename(command)} ${args.join(' ')} failed (${result.status}).${detail}`);
  }
  return `${result.stdout ?? ''}${result.stderr ?? ''}`;
}

async function main() {
  if (process.argv.slice(2).some(arg => arg !== '--check')) throw new Error('Usage: node scripts/build-apk.mjs [--check]');
  if (Number(process.versions.node.split('.')[0]) < 22) throw new Error('Node 22+ is required. Use the included GitHub Actions workflow if this computer does not have Android build tools.');

  const config = JSON.parse(await readFile('native-config.json', 'utf8'));
  if (!Number.isInteger(config.minSdkVersion) || config.minSdkVersion < 24 || !Number.isInteger(config.targetSdkVersion) || config.targetSdkVersion < config.minSdkVersion) {
    throw new Error('Invalid Android SDK versions in native-config.json. Capacitor 8 requires minSdkVersion 24+.');
  }
  const java = process.env.JAVA_HOME ? path.join(process.env.JAVA_HOME, 'bin', windows ? 'java.exe' : 'java') : 'java';
  const javaVersion = execute(java, ['-version'], { capture: true });
  const javaMajor = Number(javaVersion.match(/version\s+"(\d+)/)?.[1]);
  if (!javaMajor || javaMajor < 21) throw new Error(`JDK 21+ is required. Set JAVA_HOME to an installed JDK 21 or newer.\n${javaVersion}`);

  const sdkCandidates = [
    process.env.ANDROID_HOME,
    process.env.ANDROID_SDK_ROOT,
    process.platform === 'darwin' ? path.join(os.homedir(), 'Library', 'Android', 'sdk') : null,
    windows ? path.join(process.env.LOCALAPPDATA ?? path.join(os.homedir(), 'AppData', 'Local'), 'Android', 'Sdk') : null,
    path.join(os.homedir(), 'Android', 'Sdk'),
  ];
  const sdk = sdkCandidates.find(candidate => candidate && existsSync(path.join(candidate, 'platforms', `android-${config.targetSdkVersion}`, 'android.jar')));
  if (!sdk) throw new Error(`Android SDK Platform ${config.targetSdkVersion} was not found. Set ANDROID_HOME and install platforms;android-${config.targetSdkVersion}, or use the GitHub Actions workflow.`);
  const toolDirectory = path.join(sdk, 'build-tools', buildToolsVersion);
  const signer = path.join(toolDirectory, windows ? 'apksigner.bat' : 'apksigner');
  const aapt = path.join(toolDirectory, windows ? 'aapt.exe' : 'aapt');
  if (!existsSync(signer) || !existsSync(aapt)) throw new Error(`Install Android SDK Build Tools ${buildToolsVersion}. The APK is not published without signature and package verification.`);

  console.log(`Build tools ready: Node ${process.versions.node}, Java ${javaMajor}, Android API ${config.targetSdkVersion}.`);
  if (checkOnly) return;
  if (!existsSync('dist/index.html')) throw new Error('Build the web game first with npm run build, then run node scripts/build-apk.mjs.');

  const outputFolders = ['release-assets', 'public/downloads', 'dist/downloads'];
  // A failed new build must not leave a stale APK advertised as the latest one.
  for (const folder of outputFolders) {
    await mkdir(folder, { recursive: true });
    for (const file of [filename, `${filename}.sha256`, 'apk.json']) await rm(path.join(folder, file), { force: true });
  }

  execute(process.execPath, ['scripts/setup-android.mjs']);
  const sdkProperty = path.resolve(sdk).replace(/\\/g, '/').replace(/:/g, '\\:');
  await writeFile('android/local.properties', `sdk.dir=${sdkProperty}\n`);

  const buildNumber = process.env.APK_BUILD_NUMBER;
  if (buildNumber) {
    const code = Number(buildNumber);
    if (!Number.isSafeInteger(code) || code < 1 || code > 2_100_000_000) throw new Error('APK_BUILD_NUMBER must be a positive Android versionCode.');
    const gradle = await readFile('android/app/build.gradle', 'utf8');
    const updated = gradle.replace(/\bversionCode\s*(?:=\s*)?\d+/, `versionCode = ${code}`);
    if (updated === gradle && !new RegExp(`versionCode\\s*=\\s*${code}\\b`).test(gradle)) throw new Error('Could not set the generated Android versionCode.');
    await writeFile('android/app/build.gradle', updated);
  }

  const wrapper = path.join(root, 'android', windows ? 'gradlew.bat' : 'gradlew');
  if (!windows) await chmod(wrapper, 0o755);
  execute(wrapper, [':app:assembleDebug', '--no-daemon', '--console=plain', '--stacktrace'], { cwd: path.join(root, 'android') });

  const source = path.join(root, 'android/app/build/outputs/apk/debug/app-debug.apk');
  if (!existsSync(source)) throw new Error('Gradle did not produce app-debug.apk. No download has been published.');
  const signatureReport = execute(signer, ['verify', '--verbose', '--print-certs', source], { capture: true });
  const badging = execute(aapt, ['dump', 'badging', source], { capture: true });
  const packageInfo = badging.match(/^package: name='([^']+)' versionCode='([^']+)' versionName='([^']+)'/m);
  const minSdk = Number(badging.match(/^sdkVersion:'(\d+)'/m)?.[1]);
  const targetSdk = Number(badging.match(/^targetSdkVersion:'(\d+)'/m)?.[1]);
  if (!packageInfo || packageInfo[1] !== config.appId || minSdk !== config.minSdkVersion || targetSdk !== config.targetSdkVersion) {
    throw new Error('Compiled APK identity or SDK versions do not match native-config.json. No download has been published.');
  }
  const assetListing = execute(aapt, ['list', source], { capture: true });
  for (const required of ['assets/public/index.html', 'assets/public/images/cosmic-challenge.jpg']) {
    if (!assetListing.split(/\r?\n/).includes(required)) throw new Error(`Offline game asset ${required} is missing from the APK.`);
  }

  const binary = await readFile(source);
  if (binary.length < 100_000 || binary.readUInt32LE(0) !== 0x04034b50) throw new Error('Invalid APK archive. No download has been published.');
  const sha256 = createHash('sha256').update(binary).digest('hex');
  const metadata = {
    schemaVersion: 1,
    file: filename,
    packageId: packageInfo[1],
    version: packageInfo[3],
    versionCode: Number(packageInfo[2]),
    bytes: binary.length,
    sha256,
    minSdk,
    targetSdk,
    signing: 'debug',
    signatureVerified: true,
    builtAt: new Date().toISOString(),
  };
  const installNotes = [
    'BLAST BLOCKS - ANDROID TEST APK',
    '',
    `File: ${filename}`,
    `Package: ${metadata.packageId}`,
    `Version: ${metadata.version} (${metadata.versionCode})`,
    `Requires: Android SDK ${minSdk}+ (SDK 24 = Android 7.0)`,
    `SHA-256: ${sha256}`,
    '',
    '1. Download Blast-Blocks.apk from your own build artifact or repository release.',
    '2. Open it from your Android Downloads folder.',
    '3. If Android asks, allow this browser/file manager to install unknown apps.',
    '4. Confirm Install. You can disable that permission again afterward.',
    '',
    'Only install APKs from a source you trust. Keep Play Protect enabled.',
    'This is a debug-signed TEST build, not a Google Play release.',
    'The game is bundled and works offline from its first launch.',
    'Web-browser progress does not automatically transfer into the APK.',
    'An existing install can update only if the signing key and package ID match.',
    'Uninstalling the game deletes its local progress.',
    '',
  ].join('\n');
  for (const folder of outputFolders) {
    await copyFile(source, path.join(folder, filename));
    await writeFile(path.join(folder, `${filename}.sha256`), `${sha256}  ${filename}\n`);
    await writeFile(path.join(folder, 'apk.json'), `${JSON.stringify(metadata, null, 2)}\n`);
  }
  await writeFile('release-assets/INSTALL-APK.txt', installNotes);
  await writeFile('release-assets/apk-signature-verification.txt', signatureReport);
  await writeFile('release-assets/RELEASE-NOTES.md', `# Blast Blocks Android test build\n\nDownload **${filename}** below and open it on an Android phone (API ${minSdk}+).\n\nThis is a debug-signed test APK, not a Play Store release. Android may ask you to allow installation from the browser or file manager. Keep Play Protect enabled and install only builds from a source you trust.\n\nThe Android package is \`${metadata.packageId}\`, version \`${metadata.version}\` (${metadata.versionCode}). Game assets are bundled for offline play. Browser saves do not transfer automatically.\n\nSHA-256: \`${sha256}\`\n\nSee INSTALL-APK.txt for installation and update instructions.\n`);
  console.log(`\nVerified, debug-signed APK: release-assets/${filename}`);
  console.log(`Size: ${(binary.length / 1024 / 1024).toFixed(2)} MB | SHA-256: ${sha256}`);
  console.log('dist/ also contains the actual APK and download metadata for the in-game Install on phone screen.');
}

main().catch(error => {
  console.error(`\nAPK BUILD FAILED: ${error.message}`);
  console.error('No verified APK was generated by this run. See docs/APK_DOWNLOAD.md for the automated build option.');
  process.exitCode = 1;
});