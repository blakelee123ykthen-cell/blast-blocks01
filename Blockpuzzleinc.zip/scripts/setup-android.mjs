import { existsSync } from 'node:fs';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import sharp from 'sharp';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
process.chdir(root);
if (Number(process.versions.node.split('.')[0]) < 22) throw new Error('Capacitor 8 requires Node 22+. Install Node 22/24 LTS, then run this script again.');
if (!existsSync('dist/index.html')) throw new Error('First run npm run build. The Android application bundles dist/ for offline play.');
const config = JSON.parse(await readFile('native-config.json', 'utf8'));
if (!/^[a-z][a-z0-9]*(?:\.[a-z][a-z0-9]*){2,}$/.test(config.appId)) throw new Error('Choose a valid, unique reverse-domain appId in native-config.json.');
if (!/^ca-app-pub-\d{16}~\d{10}$/.test(config.admobAppId)) throw new Error('native-config.json must contain a valid AdMob application ID (with ~, not /).');
function cap(...args) {
  const windows = process.platform === 'win32';
  const result = spawnSync(windows ? 'npx.cmd' : 'npx', ['cap', ...args], { stdio: 'inherit', shell: windows });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`Capacitor ${args.join(' ')} failed (${result.status}).`);
}
if (!existsSync('android')) cap('add', 'android');
const appGradlePath = 'android/app/build.gradle';
const appGradle = await readFile(appGradlePath, 'utf8');
const existingId = appGradle.match(/applicationId\s*(?:=\s*)?['"]([^'"]+)['"]/i)?.[1];
if (existingId && existingId !== config.appId) throw new Error(`Existing Android ID is ${existingId}. Rename it in Android Studio, or back up custom Android changes, remove android/, and rerun this script after changing native-config.json.`);
cap('sync', 'android');
const escapeXml = value => String(value).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const manifestPath = 'android/app/src/main/AndroidManifest.xml';
let manifest = await readFile(manifestPath, 'utf8');
if (!manifest.includes('xmlns:tools=')) manifest = manifest.replace('<manifest', '<manifest xmlns:tools="http://schemas.android.com/tools"');
manifest = manifest.replace(/<activity\b([^>]*)>/g, (whole, attrs) => attrs.includes('MainActivity') ? `<activity${attrs.replace(/\sandroid:screenOrientation="[^"]*"/g, '')} android:screenOrientation="portrait">` : whole);
if (config.disableAndroidBackup) {
  manifest = manifest.replace(/<application\b([^>]*)>/, (_, attrs) => `<application${attrs.replace(/\sandroid:allowBackup="[^"]*"/g, '')} android:allowBackup="false">`);
}
manifest = manifest.replace(/<application\b([^>]*)>/, (_, attrs) => `<application${attrs.replace(/\sandroid:usesCleartextTraffic="[^"]*"/g, '')} android:usesCleartextTraffic="false">`);
manifest = manifest.replace(/\s*<meta-data\b[^>]*\/>/g, whole => whole.includes('com.google.android.gms.ads.APPLICATION_ID') ? '' : whole);
manifest = manifest.replace('</application>', `    <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="${escapeXml(config.admobAppId)}" />\n    </application>`);
for (const permission of ['android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE', 'android.permission.VIBRATE']) {
  if (!manifest.includes(`android:name="${permission}"`)) manifest = manifest.replace('</manifest>', `    <uses-permission android:name="${permission}" />\n</manifest>`);
}
if (config.removeAdvertisingIdPermission && !manifest.includes('tools:node="remove" android:name="com.google.android.gms.permission.AD_ID"')) {
  manifest = manifest.replace(/\s*<uses-permission\b[^>]*\/>/g, whole => whole.includes('com.google.android.gms.permission.AD_ID') ? '' : whole);
  manifest = manifest.replace('</manifest>', '    <uses-permission tools:node="remove" android:name="com.google.android.gms.permission.AD_ID" />\n</manifest>');
}
await writeFile(manifestPath, manifest);
const variablesPath = 'android/variables.gradle';
let variables = await readFile(variablesPath, 'utf8');
variables = variables.replace(/minSdkVersion\s*=\s*\d+/, `minSdkVersion = ${config.minSdkVersion}`).replace(/compileSdkVersion\s*=\s*\d+/, `compileSdkVersion = ${config.targetSdkVersion}`).replace(/targetSdkVersion\s*=\s*\d+/, `targetSdkVersion = ${config.targetSdkVersion}`);
await writeFile(variablesPath, variables);
const stringsPath = 'android/app/src/main/res/values/strings.xml';
let strings = await readFile(stringsPath, 'utf8');
for (const name of ['app_name', 'title_activity_main']) strings = strings.replace(new RegExp(`(<string name="${name}">)[\\s\\S]*?(</string>)`), `$1${escapeXml(config.appName)}$2`);
await writeFile(stringsPath, strings);

// Rasterize our original SVG, not a stock or third-party game icon.
const svg = await readFile('public/icon.svg');
const densities = [['mdpi', 1], ['hdpi', 1.5], ['xhdpi', 2], ['xxhdpi', 3], ['xxxhdpi', 4]];
for (const [density, multiplier] of densities) {
  const folder = `android/app/src/main/res/mipmap-${density}`;
  await mkdir(folder, { recursive: true });
  const size = Math.round(48 * multiplier);
  const legacy = await sharp(svg).resize(size, size).flatten({ background: '#0d1223' }).png().toBuffer();
  await writeFile(`${folder}/ic_launcher.png`, legacy);
  const circle = Buffer.from(`<svg width="${size}" height="${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="white"/></svg>`);
  await sharp(legacy).ensureAlpha().composite([{ input: circle, blend: 'dest-in' }]).png().toFile(`${folder}/ic_launcher_round.png`);
  await sharp(svg).resize(Math.round(108 * multiplier), Math.round(108 * multiplier)).png().toFile(`${folder}/ic_launcher_foreground.png`);
}
const adaptive = '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android"><background android:drawable="@color/game_icon_background"/><foreground android:drawable="@mipmap/ic_launcher_foreground"/></adaptive-icon>\n';
const adaptiveFolder = 'android/app/src/main/res/mipmap-anydpi-v26';
await mkdir(adaptiveFolder, { recursive: true });
await writeFile(`${adaptiveFolder}/ic_launcher.xml`, adaptive);
await writeFile(`${adaptiveFolder}/ic_launcher_round.xml`, adaptive);
await writeFile('android/app/src/main/res/values/game_icon.xml', '<?xml version="1.0" encoding="utf-8"?>\n<resources><color name="game_icon_background">#0d1223</color></resources>\n');

await mkdir('release-assets', { recursive: true });
await sharp(svg).resize(512, 512).flatten({ background: '#0d1223' }).png().toFile('release-assets/play-icon-512.png');
const artwork = `<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="500" viewBox="0 0 1024 500"><defs><radialGradient id="space"><stop stop-color="#28213c"/><stop offset="1" stop-color="#0d101b"/></radialGradient></defs><rect width="1024" height="500" fill="url(#space)"/><circle cx="788" cy="250" r="183" fill="none" stroke="#a584d3" stroke-opacity=".15"/><circle cx="788" cy="250" r="204" fill="none" stroke="#a584d3" stroke-opacity=".07"/><image href="data:image/svg+xml;base64,${svg.toString('base64')}" x="615" y="76" width="348" height="348"/><text x="75" y="134" fill="#7bdcc4" font-family="sans-serif" font-size="12" font-weight="600" letter-spacing="3">YOUR LITTLE DAILY ESCAPE</text><text x="70" y="226" fill="#f1edf9" font-family="sans-serif" font-weight="700" font-size="61" letter-spacing="-2">BLAST BLOCKS</text><text x="75" y="276" fill="#c7a9ec" font-family="sans-serif" font-size="27">Find your flow.</text><text x="75" y="329" fill="#9496ac" font-family="sans-serif" font-size="18">No timers. Endless possibilities.</text><path d="M529 83v12m-6-6h12" stroke="#d5b8fa" stroke-width="2"/><circle cx="531" cy="382" r="3" fill="#78d8c4"/></svg>`;
await writeFile('release-assets/feature-graphic.svg', artwork);
await sharp(Buffer.from(artwork)).png().toFile('release-assets/feature-graphic-1024x500.png');
console.log('\nAndroid is ready to open with npx cap open android.');
console.log(`Package: ${config.appId} | Android API ${config.targetSdkVersion} | Portrait phones`);
console.log('Original Play icon and feature graphic generated in release-assets/.');
if (config.admobAppId.includes('3940256099942544')) console.warn('DEVELOPMENT ONLY: Google demo AdMob application ID is configured. Replace it and src/config.ts ad units before release.');
