# Block Blast Puzzle: Blast Blocks — Cosmic Edition

An original, fully playable React/TypeScript block-placement puzzle with a responsive cosmic interface and a Capacitor 8 Android integration. This is not an affiliated version of another publisher's game.

## Implemented

- Real 8×8 endless puzzle, with 42 named, connected polyomino variants and fair seeded tray generation.
- Pointer-captured one-finger dragging, lifted board-sized pieces, live legal/illegal previews, line previews, smooth returns, snap animations, and tap/keyboard alternatives.
- Simultaneous horizontal/vertical clears, escalating line bonuses, consecutive-move streaks, original synthesized sound/music, native haptics, particles, and larger-clear shake.
- Main menu, pause/resume/restart, local session restore, score/best/combo display, and game-over/high-score celebrations.
- Coins, XP, player levels, free level-based cosmetics, 8 block skins, 5 board themes, and 4 real clear-effect variants. No gameplay purchases or paid advantages.
- 26 claimable achievements, rotating seeded daily challenges, and persisted once-per-day rewards.
- Locally saved best score, current game, RNG/tray, coins, XP, unlocked/equipped cosmetics, stats, achievements, daily claims, and settings.
- Optional native AdMob rewards, once-per-game fair revive, capped bonus coins, limited natural-break interstitials, menu-banner abstraction, and UMP privacy controls. No web fake ads. No launch ads. Banners off by default.
- Bundled fonts/assets, production service worker, installable web manifest, and fully offline native gameplay.
- Original SVG logo/icon, generated cosmic illustration, adaptive Android icon generator, and original Play feature-graphic generator.
- Pure integrity checks run after startup and can be rerun from Settings. A Node test suite includes save/load and unavailable-ad cases.

## Put the game on your phone

The game is not yet published on Google Play and this repository does not include a downloadable APK. To use the web version on a phone, publish/serve the full `dist/` directory on HTTPS, open that public link in Chrome on Android, and select **⋮ → Add to Home screen → Install** (or **Add**, depending on the browser). On iPhone, open the link in Safari and use **Share → Add to Home Screen → Add**.

The game includes an **Install on phone** shortcut on the home screen and in Settings. It opens a real browser install prompt when available, otherwise shows the device-specific instructions. It can copy or share the current game URL and explains the limitations of embedded/private previews and localhost. Open a private project preview in its own tab or publish a public link first. A home-screen installation is the web version, not a native APK or Play Store release. Open the web game online once and allow its service worker to cache successfully before using it offline. Local progress does not transfer between phones or browser origins.

For a native APK, the included **Build Android APK** GitHub Actions workflow can compile and publish a downloadable Android test build without local Android Studio. Export this complete project to your own GitHub repository, then run it from the Actions tab. See **`docs/APK_DOWNLOAD.md`** for step-by-step downloads and phone installation. No native compiler or GitHub execution is exposed by this editor, so no compiled APK is attached here.

The install screen checks for real generated APK metadata and the actual file before showing a download link. A successful APK build also creates a deployable website artifact containing the APK. Ordinary web-only builds deliberately show no fake download.

## Web development

Install dependencies with `npm install`, then use `npm run dev`.

Build with `npm run build`. The output is `dist/`. The Vite single-file build bundles JavaScript, CSS, and local font data into `dist/index.html`. Serve the complete `dist/` directory, not just its HTML file: public image, icon, service worker, and manifest files are also required.

`npm run preview` serves the production web build. Browser offline play is available after one online visit and successful service-worker installation. Native Android bundles all assets and works offline on the first launch. Service workers require HTTPS or localhost.

## Application/package ID

Edit **`native-config.json`**:

- `appId`: choose your own unique reverse-domain ID. Default: `games.orbit.blastblocks`.
- `appName`: installed Android display name.
- `admobAppId`: AdMob **application** ID, containing `~`.
- `minSdkVersion`: 24 by default (Android 7+).
- `targetSdkVersion`: 36 by default.

`capacitor.config.ts` imports this configuration. Set the final ID **before** generating the Android project. If the ID changes later, update Android Studio's applicationId, namespace, and Java package too, or back up custom native changes and regenerate `android/`. The setup script refuses a mismatched generated ID instead of silently creating a broken build.

## Android prerequisites

- **Node 22+** (Node 22/24 LTS recommended). The web preview can build with compatible Node 20, but Capacitor 8's CLI requires Node 22.
- **Android Studio Otter 2025.2.1+** or newer, bundled JDK 21, Android SDK Platform 36, and build tools.
- A real Android 7+ device or API 24+ emulator with an up-to-date Android System WebView.

## Generate the Android project

From the project root:

1. `npm install`
2. `npm run build`
3. `node scripts/setup-android.mjs`
4. `npx cap open android`

The setup script uses the installed Capacitor CLI to add/sync Android, locks phones to portrait, configures dark edge-to-edge system bars, sets SDK versions, disables Android app-data backup by default, adds only network/vibration permissions, removes advertising-ID permission by default, adds the development AdMob application ID, and generates the original native/Play artwork.

It generates all launcher density sizes, adaptive and round variants, `release-assets/play-icon-512.png`, and `release-assets/feature-graphic-1024x500.png` from our own SVG artwork. It does **not** create a signing key, publish an application, fabricate screenshots, or configure a production AdMob account.

After web changes, repeat `npm run build` and `node scripts/setup-android.mjs`.

### Build an installable debug APK

For a local automated build, run `node scripts/build-apk.mjs --check` to check Node/Java/SDK prerequisites. After `npm run build`, run `node scripts/build-apk.mjs`. It generates the native project, compiles Gradle, verifies the actual signature/package/offline assets, and copies the APK to `release-assets/Blast-Blocks.apk` and `dist/downloads/`. The optional GitHub workflow performs the same procedure and uploads the result; it does not require a production signing key. See `docs/APK_DOWNLOAD.md`.

After setup, enter `android/` and run `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).

Output: `android/app/build/outputs/apk/debug/app-debug.apk`.

Android Studio's Run button can also install the game on a selected emulator/device. Debug APKs are for testing, not Play distribution.

### Build a signed release APK

In Android Studio use **Build → Generate Signed App Bundle / APK → APK**. Create or select your own protected release/upload keystore, choose the release variant, and build. Save the key outside the repository. The wizard's chosen destination contains the signed APK; with a Gradle signing configuration the usual path is `android/app/build/outputs/apk/release/app-release.apk`.

### Build the Android App Bundle (.aab)

Use **Build → Generate Signed App Bundle / APK → Android App Bundle**. Select your protected upload key and release variant, then build. The chosen output directory contains the signed `.aab`.

If you have already configured secure release signing in Android Gradle, `./gradlew bundleRelease` produces `android/app/build/outputs/bundle/release/app-release.aab`. Do not upload an unsigned bundle or commit keystore/password files. Enroll in Play App Signing and increase `versionCode` for every update.

## Production advertisement IDs

There are two different configurations:

1. **`native-config.json` → `admobAppId`**: Android application ID, e.g. a `ca-app-pub-…~…` value. The setup script puts it in AndroidManifest.xml. The default is Google's Android demo application ID.
2. **`src/config.ts` → `appConfig.ads`**: set `testMode` to `false`, and fill `production.rewarded`, `production.interstitial`, and, if enabled, `production.banner`. Ad UNIT IDs contain `/`, not `~`.

Keep `testMode: true` for development and test devices. The app never invents rewarded inventory. Web, offline, missing consent, missing production IDs, and failed SDK loads simply make reward offers unavailable. Reward grants require a confirmed reward and ad dismissal. Revive empties a 5×5 central landing zone without giving free points, and is limited to once per game.

Interstitials require three finished games, at least two minutes since launch, and a three-minute minimum interval. They are shown only after game over when the user leaves/restarts. Banners default to disabled and are hidden for gameplay. Bonus-coin rewarded ads are optional and capped at three per UTC day.

Create and publish UMP consent messages in your AdMob console. Non-personalized requests and no advertising-ID permission are the defaults. Settings opens Google's native privacy-options form when available. Respect the target audience and child-directed treatment obligations; this project does not claim a children's advertising certification.

## Tests and verification

- Type check: `npx tsc --noEmit`.
- Automated Node tests: `npx tsx --test tests/*.test.ts` (gameplay, persistence, ads unavailable, and APK metadata validation).
- In-app core checks: Settings → Check game integrity. These never overwrite player saves.
- Device/interaction checklist: `docs/TESTING.md`.

The web production build is verified in the creation environment. Android Gradle builds, touch/haptic behavior on physical hardware, native ad inventory/consent flows, performance on older hardware, and actual store submission cannot be verified without the Android SDK, suitable devices, and publisher accounts. Do not treat build success as certification of these areas.

## Data and privacy

Local storage key: `orbit-block-puzzle-v1`. No accounts, analytics backend, cloud sync, payment processing, or unnecessary personal-data collection are implemented. A 250-coin welcome gift is provided once in a fresh profile. Scores and normal play rewards are saved every move; record rewards are settled once and recovered after an interrupted game-over animation.

The game includes privacy/terms notices. Before publishing, the operator must add their legal identity/support contact, host a public privacy policy, verify SDK Data Safety disclosures, and adapt terms for applicable law. Google AdMob may process device/network/ad data when enabled; it must be declared. Resetting app data or uninstalling loses local progress. Android cloud backup is disabled by the setup script by default.

## Known limitations / release gates

No identified core gameplay bug is left intentionally unresolved. Browser vibration and Web Audio depend on platform support and user interaction. Service-worker caching requires one online web visit, unlike the native bundle. No cloud save is promised. Daily claims use the device's UTC date and local storage; this is not a server-enforced anti-tamper economy.

The final dependency installation reports four audit advisories (one low, three moderate; no high/critical findings). Review `npm audit` and update or formally assess each affected dependency before release. Native packages require Node 22; do not use the Node 20 preview environment for native generation. Native signing, device QA, UMP/AdMob-account setup, publisher privacy details, and Play submission remain publisher-side tasks.

## Remaining Google Play requirements

See `docs/PLAY_LISTING.md` for honest metadata and asset guidance. Supply real screenshots, a public operator-specific policy URL, support email, content rating and target audience, accurate contains-ads/Data Safety declarations, signing and versioning, and any required closed-testing enrollment. Check current SDK, 16 KB memory-page compatibility, account verification, and production-access requirements in Play Console.

Google's published requirement is Android API 36 for new apps/updates from August 31, 2026. This integration targets 36, but verify the requirements at submission time. Perform your own title/trademark clearance; the requested internal full name is 32 characters, so the suggested compliant 27-character listing is **Blast Blocks: Cosmic Puzzle**.

## Original assets and licenses

Logo/icon, interface, game code, generated cosmic illustration, synthesized effects, and background melody were created for this implementation. Lucide icons are ISC licensed; DM Sans and Space Grotesk are SIL Open Font License; React, Vite, Capacitor, the AdMob community adapter, and other dependencies retain their own licenses. Fonts are bundled locally. Review all dependency and generated-asset licensing as part of your commercial release process.
