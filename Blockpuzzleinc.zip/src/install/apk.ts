export interface AndroidApkInfo {
  schemaVersion: 1;
  file: 'Blast-Blocks.apk';
  packageId: string;
  version: string;
  versionCode: number;
  bytes: number;
  sha256: string;
  minSdk: number;
  targetSdk: number;
  signing: 'debug' | 'release';
  signatureVerified: true;
  builtAt: string;
}

export function parseApkInfo(value: unknown): AndroidApkInfo | null {
  if (!value || typeof value !== 'object') return null;
  const info = value as Record<string, unknown>;
  if (info.schemaVersion !== 1 || info.file !== 'Blast-Blocks.apk' || info.signatureVerified !== true) return null;
  if (info.signing !== 'debug' && info.signing !== 'release') return null;
  if (typeof info.packageId !== 'string' || !/^[a-z][a-z0-9]*(?:\.[a-z][a-z0-9]*){2,}$/.test(info.packageId)) return null;
  if (typeof info.version !== 'string' || !info.version.trim() || info.version.length > 40) return null;
  if (typeof info.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(info.sha256)) return null;
  if (typeof info.bytes !== 'number' || !Number.isSafeInteger(info.bytes) || info.bytes < 100_000 || info.bytes > 500_000_000) return null;
  if (typeof info.versionCode !== 'number' || !Number.isSafeInteger(info.versionCode) || info.versionCode < 1 || info.versionCode > 2_100_000_000) return null;
  if (typeof info.minSdk !== 'number' || !Number.isInteger(info.minSdk) || info.minSdk < 24 || info.minSdk > 100) return null;
  if (typeof info.targetSdk !== 'number' || !Number.isInteger(info.targetSdk) || info.targetSdk < info.minSdk || info.targetSdk > 100) return null;
  if (typeof info.builtAt !== 'string' || !Number.isFinite(Date.parse(info.builtAt))) return null;
  return info as unknown as AndroidApkInfo;
}

export function formatApkSize(bytes: number): string {
  return bytes >= 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${Math.ceil(bytes / 1024)} KB`;
}

export function androidRequirement(minSdk: number): string {
  return minSdk === 24 ? 'Android 7 or newer' : `Android API ${minSdk} or newer`;
}