// Release configuration. Google demo IDs are deliberately the development default.
// Set testMode to false and supply your own ad UNIT IDs before a production release.
export const appConfig = {
  ads: {
    enabled: true,
    testMode: true,
    bannerEnabled: false,
    personalizedByDefault: false,
    minimumInterstitialIntervalMs: 180_000,
    test: {
      rewarded: 'ca-app-pub-3940256099942544/5224354917',
      interstitial: 'ca-app-pub-3940256099942544/1033173712',
      banner: 'ca-app-pub-3940256099942544/6300978111',
    },
    production: { rewarded: '', interstitial: '', banner: '' },
  },
} as const;
