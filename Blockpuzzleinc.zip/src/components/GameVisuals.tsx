import { type CSSProperties, type RefObject, type KeyboardEvent } from 'react';
import { completedLines, dimensions, type Board as BoardData, type Piece } from '../game/engine';
import { blockColor } from '../game/profile';

export function BrandMark({ size = 42 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 44 44" fill="none" aria-hidden="true" className="brand-mark">
    <rect x="1" y="1" width="13" height="13" rx="3.5" fill="#AF8BF6" />
    <rect x="16" y="1" width="13" height="13" rx="3.5" fill="#9B72EB" />
    <rect x="1" y="16" width="13" height="13" rx="3.5" fill="#9B72EB" />
    <rect x="16" y="16" width="13" height="13" rx="3.5" fill="#53D6C5" />
    <rect x="31" y="16" width="12" height="13" rx="3.5" fill="#43BFAF" />
    <rect x="16" y="31" width="13" height="12" rx="3.5" fill="#EDAA6B" />
    <path d="M35 2v7m-3.5-3.5h7" stroke="#ECD8FF" strokeWidth="1.7" strokeLinecap="round" />
  </svg>;
}
export function OrbitMark({ size = 44 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-hidden="true">
    <circle cx="32" cy="32" r="15" fill="url(#orbit-gradient)" />
    <ellipse cx="32" cy="32" rx="27" ry="9" transform="rotate(-32 32 32)" stroke="#D1BAFF" strokeWidth="2" />
    <circle cx="49" cy="13" r="3" fill="#6FE3D0" />
    <path d="M12 12v6m-3-3h6" stroke="#C4AAF9" strokeWidth="1.5" strokeLinecap="round" />
    <defs><linearGradient id="orbit-gradient" x1="20" y1="17" x2="44" y2="46" gradientUnits="userSpaceOnUse"><stop stopColor="#C59EFA" /><stop offset="1" stopColor="#6550B5" /></linearGradient></defs>
  </svg>;
}
export function PieceShape({ piece, unit = 25, gap = 4, skin = 'neon', className = '' }: { piece: Piece; unit?: number; gap?: number; skin?: string; className?: string }) {
  const { width, height } = dimensions(piece);
  return <div className={`piece-shape ${className}`} style={{ width: width * unit - gap, height: height * unit - gap }} aria-hidden="true">
    {piece.cells.map(([x, y], i) => <span key={i} className="block piece-block" style={{ '--block-color': blockColor(piece.color, skin), width: unit - gap, height: unit - gap, left: x * unit, top: y * unit } as CSSProperties} />)}
  </div>;
}
export interface PlacementPreview { piece: Piece; row: number; col: number; valid: boolean }
interface BoardProps {
  board: BoardData; skin: string; boardRef?: RefObject<HTMLDivElement | null>;
  preview?: PlacementPreview | null; clearing?: number[]; placed?: number[]; cursor?: number;
  onCell?: (row: number, col: number) => void; onHover?: (row: number, col: number) => void;
  onLeave?: () => void; onKey?: (index: number, event: KeyboardEvent<HTMLButtonElement>) => void;
  decorative?: boolean;
}
export function Board({ board, skin, boardRef, preview, clearing = [], placed = [], cursor = 0, onCell, onHover, onLeave, onKey, decorative = false }: BoardProps) {
  const ghosts = new Set<number>(), highlighted = new Set<number>();
  if (preview) {
    preview.piece.cells.forEach(([x, y]) => { const r = preview.row + y, c = preview.col + x; if (r >= 0 && r < 8 && c >= 0 && c < 8) ghosts.add(r * 8 + c); });
    if (preview.valid) {
      const candidate = [...board]; ghosts.forEach(i => { candidate[i] = preview.piece.color; });
      completedLines(candidate).indices.forEach(i => highlighted.add(i));
    }
  }
  return <div className="game-board" ref={boardRef} role={decorative ? 'img' : 'grid'} aria-label={decorative ? 'An original colorful block puzzle arrangement' : '8 by 8 puzzle board'} aria-rowcount={decorative ? undefined : 8} aria-colcount={decorative ? undefined : 8} onPointerLeave={onLeave}>
    {board.map((color, i) => {
      const ghost = ghosts.has(i), clear = clearing.includes(i), isPlaced = placed.includes(i);
      const classes = `board-cell ${color !== null ? 'filled' : ''} ${ghost ? preview?.valid ? 'preview-valid' : 'preview-invalid' : ''} ${highlighted.has(i) ? 'preview-line' : ''} ${clear ? 'clearing' : ''} ${isPlaced && !clear ? 'just-placed' : ''}`;
      const style = { '--block-color': blockColor(ghost && color === null ? preview!.piece.color : color ?? 0, skin) } as CSSProperties;
      if (decorative) return <div key={i} className={classes} style={style}>{color !== null && <span className="block cell-block" />}</div>;
      return <button key={i} type="button" className={classes} style={style} role="gridcell" aria-rowindex={Math.floor(i / 8) + 1} aria-colindex={i % 8 + 1} aria-label={`Row ${Math.floor(i / 8) + 1}, column ${i % 8 + 1}, ${color === null ? 'empty' : 'occupied'}${ghost ? preview?.valid ? ', valid placement' : ', invalid placement' : ''}`} tabIndex={i === cursor ? 0 : -1} onClick={() => onCell?.(Math.floor(i / 8), i % 8)} onPointerEnter={() => onHover?.(Math.floor(i / 8), i % 8)} onFocus={() => onHover?.(Math.floor(i / 8), i % 8)} onKeyDown={e => onKey?.(i, e)}>
        {color !== null && <span className="block cell-block" />}
        {ghost && color === null && <span className="block ghost-block" />}
      </button>;
    })}
  </div>;
}
export function ParticleBurst({ cells, board, skin, effect }: { cells: number[]; board: BoardData; skin: string; effect: string }) {
  return <div className={`particle-layer effect-${effect}`} aria-hidden="true">
    {cells.slice(0, 40).flatMap((cell, n) => [0, 1, 2].map(j => {
      const angle = (n * 2.39996 + j * 2.0944), length = 24 + (n * 13 + j * 21) % 74;
      return <i key={`${cell}-${j}`} className="particle" style={{ left: `${((cell % 8) + .5) / 8 * 100}%`, top: `${(Math.floor(cell / 8) + .5) / 8 * 100}%`, '--dx': `${Math.cos(angle) * length}px`, '--dy': `${Math.sin(angle) * length}px`, '--particle-color': blockColor(board[cell] ?? n % 7, skin), '--delay': `${j * 12}ms`, '--rotation': `${n * 43}deg` } as CSSProperties} />;
    }))}
  </div>;
}
export function SkinSwatch({ skin }: { skin: string }) {
  const positions = [[0, 0], [1, 0], [1, 1], [2, 1], [0, 2], [1, 2], [2, 2]];
  return <div className="skin-swatch" aria-hidden="true">{positions.map(([x, y], i) => <span key={i} className="block" style={{ left: x * 35, top: y * 35, width: 30, height: 30, '--block-color': blockColor(i, skin) } as CSSProperties} />)}<i className="swatch-spark spark-one" /><i className="swatch-spark spark-two" /></div>;
}
