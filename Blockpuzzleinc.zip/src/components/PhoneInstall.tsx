import { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, Check, CheckCircle2, Copy, Download, ExternalLink, Link2, MoreVertical, Share2, Smartphone, WifiOff } from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { Dialog } from './Dialog';
import { AndroidApkDownload } from './AndroidApkDownload';
import './PhoneInstall.css';

interface BrowserInstallEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}
export function usePhoneInstall() {
  const pending = useRef<BrowserInstallEvent | null>(null);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [installed, setInstalled] = useState(() => Capacitor.isNativePlatform() || window.matchMedia('(display-mode: standalone)').matches || (navigator as Navigator & { standalone?: boolean }).standalone === true);
  useEffect(() => {
    const standalone = window.matchMedia('(display-mode: standalone)');
    const before = (event: Event) => {
      event.preventDefault(); pending.current = event as BrowserInstallEvent; setReady(true);
    };
    const done = () => { pending.current = null; setReady(false); setInstalled(true); };
    const display = () => setInstalled(Capacitor.isNativePlatform() || standalone.matches || (navigator as Navigator & { standalone?: boolean }).standalone === true);
    window.addEventListener('beforeinstallprompt', before);
    window.addEventListener('appinstalled', done);
    standalone.addEventListener?.('change', display);
    return () => {
      window.removeEventListener('beforeinstallprompt', before);
      window.removeEventListener('appinstalled', done);
      standalone.removeEventListener?.('change', display);
    };
  }, []);
  async function install(): Promise<'accepted' | 'dismissed' | 'unavailable'> {
    const event = pending.current;
    if (!event || busy) return 'unavailable';
    pending.current = null; setReady(false); setBusy(true);
    try { await event.prompt(); const choice = await event.userChoice; return choice.outcome; }
    catch { return 'unavailable'; }
    finally { setBusy(false); }
  }
  return { ready, busy, installed, install };
}
type InstallState = ReturnType<typeof usePhoneInstall>;
export function PhoneInstall({ state, onClose, notify }: { state: InstallState; onClose: () => void; notify: (title: string, description?: string) => void }) {
  const [platform, setPlatform] = useState<'android' | 'ios'>(() => /iPad|iPhone|iPod/.test(navigator.userAgent) ? 'ios' : 'android');
  const [copied, setCopied] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const embedded = window.self !== window.top;
  const native = Capacitor.isNativePlatform();
  const url = new URL(window.location.href);
  url.hash = '';
  const gameUrl = url.href;
  const isLocal = ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname);
  async function copyLink() {
    try {
      if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
      await navigator.clipboard.writeText(gameUrl); setCopied(true);
      notify('Game link copied', 'Send it to your phone, then open it in Chrome. Private preview links may need publishing first.');
    } catch {
      input.current?.focus(); input.current?.select();
      notify('Copy the selected game address', 'Your browser blocked automatic copying. Copy the highlighted link manually.');
    }
  }
  async function shareLink() {
    if (!navigator.share) { await copyLink(); return; }
    try { await navigator.share({ title: 'Blast Blocks: Cosmic Puzzle', text: 'An original offline-friendly block puzzle. Open in Chrome to add it to your home screen.', url: gameUrl }); }
    catch (error) { if (!(error instanceof DOMException && error.name === 'AbortError')) await copyLink(); }
  }
  async function promptInstall() {
    const outcome = await state.install();
    if (outcome === 'accepted') notify('Installation requested', 'Confirm any remaining browser prompts, then look for Blast Blocks on your home screen.');
    else if (outcome === 'dismissed') notify('Install whenever you’re ready', 'You can keep playing here, or use Chrome’s Add to Home screen menu later.');
    else notify('Use your browser’s install menu', 'Open the game in Chrome, then choose Add to Home screen or Install app.');
  }
  return <Dialog title={state.installed ? 'Already in your orbit.' : 'Take your orbit with you.'} eyebrow="INSTALL ON PHONE" description={state.installed ? 'You’re already running the installed game.' : 'Install the web game from your browser, or check below for an Android APK. This game is not published on Google Play.'} onClose={onClose}>
    <div className="phone-install-art"><div /><Smartphone size={52} /><span>{state.installed ? <Check size={15} /> : <Download size={15} />}</span></div>
    {state.installed ? <div className="phone-installed"><CheckCircle2 size={18} /><span>Installed and ready to play</span></div> : <>
      {embedded && <div className="install-notice"><ExternalLink size={16} /><p>You’re in an embedded preview. Open the game in its own browser tab first. A private preview may need to be published before your phone can access it.</p></div>}
      {isLocal && <div className="install-notice"><Link2 size={16} /><p>This is a local development address. Publish the game to a public HTTPS link before opening it on another phone.</p></div>}
      {embedded && <a className="button button-primary full-width install-open-link" href={gameUrl} target="_blank" rel="noopener noreferrer"><ExternalLink size={15} />Open game in its own tab<ArrowUpRight size={16} /></a>}
      {state.ready && !embedded && <button className="button button-primary full-width" disabled={state.busy} onClick={() => void promptInstall()}><Download size={16} />{state.busy ? 'Opening install prompt…' : 'Install game'}<ArrowUpRight size={16} /></button>}
      <div className="tabs install-platform-tabs"><button className={platform === 'android' ? 'active' : ''} onClick={() => setPlatform('android')}>Android · Chrome</button><button className={platform === 'ios' ? 'active' : ''} onClick={() => setPlatform('ios')}>iPhone · Safari</button></div>
      <ol className="phone-install-steps">
        <li><span>1</span><div><strong>Open the game link.</strong><p>{platform === 'android' ? 'Use Chrome on your Android phone, in a regular browser tab.' : 'Use Safari on your iPhone, outside an in-app browser.'}</p></div></li>
        <li><span>2</span><div><strong>{platform === 'android' ? <><MoreVertical size={14} />Open Chrome’s menu.</> : <><Share2 size={14} />Tap the Share button.</>}</strong><p>{platform === 'android' ? 'Choose “Add to Home screen” or “Install app”.' : 'Choose “Add to Home Screen”. You may need to scroll through the actions.'}</p></div></li>
        <li><span>3</span><div><strong>{platform === 'android' ? 'Confirm Install or Add.' : 'Tap Add to finish.'}</strong><p>Look for Blast Blocks on your home screen. Open it while online once so the offline files can finish saving.</p></div></li>
      </ol>
    </>}
    {!native && platform === 'android' && <AndroidApkDownload />}
    {!native && <section className="install-share-section"><label htmlFor="install-game-url"><Link2 size={13} />GAME LINK</label><input id="install-game-url" ref={input} readOnly value={gameUrl} onFocus={event => event.currentTarget.select()} spellCheck={false} /><div><button className="button button-outline" onClick={() => void copyLink()}>{copied ? <Check size={14} /> : <Copy size={14} />}{copied ? 'Link copied' : 'Copy game link'}</button><button className="button button-outline" onClick={() => void shareLink()}><Share2 size={14} />Share link</button></div><p>A published HTTPS link works best. Installing on another device does not transfer your existing score or coins.</p></section>}
    <div className="install-offline-note"><WifiOff size={15} /><p>{native ? 'The Android game is bundled for offline play from its first launch. Progress stays inside this app on this device.' : 'Play offline after the web game has cached successfully. Progress stays on the device and browser where you play.'}</p></div>
    <button className="text-button" onClick={onClose}>Back to my orbit</button>
  </Dialog>;
}
