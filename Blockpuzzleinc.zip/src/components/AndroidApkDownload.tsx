import { useEffect, useState } from 'react';
import { ChevronDown, Download, FileArchive, RotateCcw, ShieldCheck } from 'lucide-react';
import { androidRequirement, formatApkSize, parseApkInfo, type AndroidApkInfo } from '../install/apk';
import './AndroidApkDownload.css';

export function AndroidApkDownload() {
  const [status, setStatus] = useState<'checking' | 'available' | 'unavailable'>('checking');
  const [info, setInfo] = useState<AndroidApkInfo | null>(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 6000);
    let active = true;
    setStatus('checking'); setInfo(null);
    void (async () => {
      try {
        const response = await fetch('/downloads/apk.json', { signal: controller.signal, cache: 'no-store' });
        if (!response.ok) throw new Error('No compiled APK metadata');
        const metadata = parseApkInfo(await response.json());
        if (!metadata) throw new Error('Invalid APK metadata');
        const artifact = await fetch(`/downloads/${metadata.file}`, { method: 'HEAD', signal: controller.signal, cache: 'no-store' });
        if (!artifact.ok || artifact.headers.get('content-type')?.includes('text/html')) throw new Error('APK file is not hosted');
        const size = artifact.headers.get('content-length');
        const encoding = artifact.headers.get('content-encoding');
        if (size && (!encoding || encoding === 'identity') && Number(size) !== metadata.bytes) throw new Error('APK file does not match this build');
        if (active) { setInfo(metadata); setStatus('available'); }
      } catch {
        if (active) setStatus('unavailable');
      } finally { clearTimeout(timeout); }
    })();
    return () => { active = false; clearTimeout(timeout); controller.abort(); };
  }, [attempt]);

  return <details className="apk-download-panel">
    <summary><FileArchive size={16} /><strong>Android APK</strong><span className={status === 'available' ? 'apk-status-ready' : ''}>{status === 'checking' ? 'Checking' : status === 'available' ? 'Download ready' : 'Not built here yet'}</span><ChevronDown size={15} /></summary>
    <div className="apk-download-content">
      {status === 'checking' ? <p className="apk-checking" role="status">Checking this website for an actual compiled Android file.</p> : status === 'available' && info ? <>
        <div className="apk-file-heading"><div><h3>Blast-Blocks.apk</h3><p>{formatApkSize(info.bytes)} · {androidRequirement(info.minSdk)}</p></div><span>{info.signing === 'debug' ? 'TEST BUILD' : 'RELEASE BUILD'}</span></div>
        <a className="button button-primary full-width apk-download-button" href={`/downloads/${info.file}`} download={info.file}><Download size={16} />Download Android APK</a>
        <p className="apk-install-instructions">Open the downloaded file on your Android phone and confirm Install. Android may ask you to allow installations from this browser or file manager.</p>
        <div className="apk-trust-note"><ShieldCheck size={15} /><p>Install only builds from a source you trust. Keep Play Protect enabled. {info.signing === 'debug' ? 'This is a debug-signed test APK, not a Google Play release.' : 'This APK is distributed directly, not through Google Play.'}</p></div>
        <dl className="apk-build-information"><dt>Package</dt><dd>{info.packageId}</dd><dt>Version</dt><dd>{info.version} ({info.versionCode})</dd><dt>SHA-256</dt><dd className="apk-hash">{info.sha256}</dd></dl>
        <p className="apk-save-warning">Browser progress does not automatically transfer to a native APK. Uninstalling an existing native game deletes its local saves.</p>
      </> : <>
        <h3>A real APK needs an Android build.</h3>
        <p>No compiled APK could be found at this website. The project includes a GitHub workflow that builds one without Android Studio.</p>
        <ol className="apk-build-steps"><li>Export the complete project to a GitHub repository, including the hidden .github folder.</li><li>Open Actions, select <strong>Build Android APK</strong>, and choose Run workflow.</li><li>After a successful build, open Releases and download <strong>Blast-Blocks.apk</strong>.</li></ol>
        <p className="apk-save-warning">This editor cannot compile or download an APK by itself. The workflow must run successfully first. It produces an Android 7+ test build, not a Play Store release.</p>
        <button className="text-button apk-check-again" onClick={() => setAttempt(current => current + 1)}><RotateCcw size={13} />Check for a built APK again</button>
      </>}
    </div>
  </details>;
}