import { Capacitor } from '@capacitor/core';
import { Haptics, ImpactStyle } from '@capacitor/haptics';

export type Sound = 'button' | 'place' | 'clear' | 'combo' | 'mega' | 'over' | 'record' | 'level' | 'reward' | 'invalid';
class CosmicAudio {
  private context: AudioContext | null = null;
  private enabled = true;
  private musicEnabled = false;
  private musicTimer: ReturnType<typeof setInterval> | null = null;
  private unlocked = false;
  private suspended = false;
  private ensure(): AudioContext | null {
    try {
      if (!this.context) {
        const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.context = new Ctx();
      }
      if (this.context.state === 'suspended') void this.context.resume().catch(() => {});
      return this.context;
    } catch { return null; }
  }
  unlock() { this.unlocked = true; this.ensure(); this.syncMusic(); }
  configure(sound: boolean, music: boolean) { this.enabled = sound; this.musicEnabled = music; this.syncMusic(); }
  suspend(value: boolean) {
    this.suspended = value;
    if (value) void this.context?.suspend().catch(() => {});
    else if (this.unlocked) this.ensure();
    this.syncMusic();
  }
  private tone(frequency: number, time: number, duration: number, volume: number, type: OscillatorType = 'sine') {
    const ctx = this.context;
    if (!ctx) return;
    const oscillator = ctx.createOscillator(), gain = ctx.createGain();
    oscillator.type = type; oscillator.frequency.setValueAtTime(frequency, time);
    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(volume, time + .012);
    gain.gain.exponentialRampToValueAtTime(.0001, time + duration);
    oscillator.connect(gain); gain.connect(ctx.destination);
    oscillator.start(time); oscillator.stop(time + duration + .03);
    oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
  }
  play(sound: Sound) {
    if (!this.enabled || this.suspended) return;
    const ctx = this.ensure(); if (!ctx) return;
    const scores: Record<Sound, number[]> = {
      button: [660], place: [392, 587.33], clear: [523.25, 659.25, 783.99],
      combo: [659.25, 783.99, 1046.5], mega: [523.25, 659.25, 783.99, 1046.5, 1318.5],
      over: [392, 329.63, 261.63, 196], record: [523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98],
      level: [392, 523.25, 659.25, 1046.5], reward: [659.25, 783.99, 1046.5], invalid: [196],
    };
    const notes = scores[sound];
    notes.forEach((note, i) => this.tone(note, ctx.currentTime + i * (sound === 'over' ? .12 : .055), sound === 'button' ? .07 : .2, sound === 'button' ? .035 : .065, sound === 'place' ? 'triangle' : 'sine'));
  }
  private syncMusic() {
    if (this.musicTimer) { clearInterval(this.musicTimer); this.musicTimer = null; }
    if (!this.musicEnabled || !this.unlocked || this.suspended) return;
    const playPhrase = () => {
      const ctx = this.ensure(); if (!ctx) return;
      [130.81, 196, 164.81, 246.94, 196, 164.81].forEach((note, i) => {
        this.tone(note, ctx.currentTime + i * .55, 1.25, .013, 'sine');
        this.tone(note * 2, ctx.currentTime + i * .55 + .15, .8, .005, 'triangle');
      });
    };
    playPhrase(); this.musicTimer = setInterval(playPhrase, 4400);
  }
}
export const audio = new CosmicAudio();
export function haptic(enabled: boolean, large = false) {
  if (!enabled) return;
  if (Capacitor.isNativePlatform()) void Haptics.impact({ style: large ? ImpactStyle.Medium : ImpactStyle.Light }).catch(() => {});
  else if ('vibrate' in navigator) { try { navigator.vibrate(large ? [12, 25, 12] : 8); } catch { /* unsupported hardware */ } }
}
