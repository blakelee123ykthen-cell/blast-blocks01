import { SHAPES, canPlace, completedLines, emptyBoard, generateTray, hasLegalPlacement, isGameOver, lineBonus, newGame, placePiece, reviveGame, utcDay, type Board, type Coordinate, type Game, type Piece } from './engine';
import { ACHIEVEMENTS, COSMETICS, PALETTES, advanceDaily, applyLevelUnlocks, claimAchievement, claimDailyReward, dailyMission, defaultProfile, levelInfo, purchaseCosmetic } from './profile';

export interface CheckResult { name: string; passed: boolean; error?: string }
function assert(condition: unknown, message = 'Invariant was not satisfied'): asserts condition { if (!condition) throw new Error(message); }
const testPiece = (cells: Coordinate[], id = 'test'): Piece => ({ id, cells, color: 0, name: 'Test constellation' });
const single = testPiece([[0, 0]]);
function testGame(board = emptyBoard(), pieces: (Piece | null)[] = [single, single, single]): Game {
  return { ...newGame('endless', 0, '2026-07-01', 12345), board, pieces };
}
function almostRows(count: number): Board {
  const b = emptyBoard(); for (let r = 0; r < count; r++) for (let c = 0; c < 7; c++) b[r * 8 + c] = r % 7;
  return b;
}
export function runCoreChecks(): CheckResult[] {
  const results: CheckResult[] = [];
  const check = (name: string, fn: () => void) => {
    try { fn(); results.push({ name, passed: true }); } catch (error) { results.push({ name, passed: false, error: error instanceof Error ? error.message : String(error) }); }
  };
  check('Board is exactly 8 × 8', () => { assert(emptyBoard().length === 64 && emptyBoard().every(c => c === null)); });
  check('42 unique, connected original shapes', () => {
    assert(SHAPES.length === 42);
    const signatures = new Set<string>();
    SHAPES.forEach(s => {
      const signature = [...s.cells].sort((a, b) => a[1] * 8 + a[0] - b[1] * 8 - b[0]).map(c => c.join(',')).join(';');
      assert(!signatures.has(signature), `Duplicate shape: ${s.name}`); signatures.add(signature);
      const visited = new Set([s.cells[0].join(',')]);
      let changed = true;
      while (changed) { changed = false; s.cells.forEach(([x, y]) => { const key = `${x},${y}`; if (!visited.has(key) && [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]].some(c => visited.has(c.join(',')))) { visited.add(key); changed = true; } }); }
      assert(visited.size === s.cells.length, `Disconnected shape: ${s.name}`);
    });
  });
  check('Single squares fit board corners', () => { assert(canPlace(emptyBoard(), single, 0, 0) && canPlace(emptyBoard(), single, 7, 7)); });
  check('Out-of-bounds placements are rejected', () => { assert(!canPlace(emptyBoard(), single, -1, 0) && !canPlace(emptyBoard(), single, 8, 7) && !canPlace(emptyBoard(), single, 0, 8)); });
  check('Overlapping placements are rejected', () => { const b = emptyBoard(); b[0] = 1; assert(!canPlace(b, single, 0, 0)); });
  check('Horizontal shapes respect the right edge', () => { const p = testPiece([[0, 0], [1, 0], [2, 0]]); assert(canPlace(emptyBoard(), p, 0, 5) && !canPlace(emptyBoard(), p, 0, 6)); });
  check('Vertical shapes respect the bottom edge', () => { const p = testPiece([[0, 0], [0, 1], [0, 2]]); assert(canPlace(emptyBoard(), p, 5, 0) && !canPlace(emptyBoard(), p, 6, 0)); });
  check('Placement gives 10 points per square', () => { const g = testGame(emptyBoard(), [testPiece([[0, 0], [1, 0], [0, 1], [1, 1]]), single, single]); const r = placePiece(g, 0, 0, 0); assert(r?.points === 40 && r.game.score === 40 && r.placed.length === 4); });
  check('Invalid moves do not mutate game state', () => { const g = testGame(); const snapshot = JSON.stringify(g); assert(placePiece(g, 0, -1, 0) === null && JSON.stringify(g) === snapshot); });
  check('Already-placed pieces cannot be used twice', () => { const g = testGame(emptyBoard(), [null, single, single]); assert(placePiece(g, 0, 0, 0) === null); });
  check('Full horizontal rows clear correctly', () => { const r = placePiece(testGame(almostRows(1)), 0, 0, 7); assert(r?.lineCount === 1 && r.rows[0] === 0 && r.cleared.length === 8 && r.points === 110 && r.game.board.slice(0, 8).every(c => c === null)); });
  check('Full vertical columns clear correctly', () => { const b = emptyBoard(); for (let r = 0; r < 7; r++) b[r * 8] = 1; const move = placePiece(testGame(b), 0, 7, 0); assert(move?.lineCount === 1 && move.columns[0] === 0 && move.cleared.length === 8 && move.points === 110); });
  check('Cross clears count both lines and remove the intersection once', () => { const b = emptyBoard(); for (let i = 1; i < 8; i++) { b[i] = 1; b[i * 8] = 2; } const r = placePiece(testGame(b), 0, 0, 0); assert(r?.lineCount === 2 && r.cleared.length === 15 && r.points === 260 && r.game.board.every(c => c === null)); });
  check('Three-line simultaneous bonus is 500', () => { const p = testPiece([[0, 0], [0, 1], [0, 2]]); const r = placePiece(testGame(almostRows(3), [p, single, single]), 0, 0, 7); assert(r?.lineCount === 3 && r.points === 530 && r.cleared.length === 24); });
  check('Four-line simultaneous bonus is 1,000', () => { const p = testPiece([[0, 0], [0, 1], [0, 2], [0, 3]]); const r = placePiece(testGame(almostRows(4), [p, single, single]), 0, 0, 7); assert(r?.lineCount === 4 && r.points === 1040 && r.cleared.length === 32); });
  check('Consecutive clears multiply the line bonus', () => { const g = { ...testGame(almostRows(1)), combo: 2 }; const r = placePiece(g, 0, 0, 7); assert(r?.game.combo === 3 && r.points === 310 && r.game.maxCombo === 3); });
  check('Non-clearing moves reset the streak', () => { const r = placePiece({ ...testGame(), combo: 5 }, 0, 0, 0); assert(r?.game.combo === 0 && r.points === 10); });
  check('Line bonuses increase with larger clears', () => { assert(lineBonus(0) === 0 && lineBonus(1) === 100 && lineBonus(2) === 250 && lineBonus(3) === 500 && lineBonus(4) === 1000 && lineBonus(5) > 1000); });
  check('A new tray appears only after all three pieces are placed', () => {
    const one = placePiece(testGame(), 0, 0, 0); assert(one?.game.pieces[0] === null && one.game.pieces[1] !== null);
    const last = placePiece(testGame(emptyBoard(), [single, null, null]), 0, 0, 0); assert(last?.game.pieces.every(p => p !== null) && last.game.pieces.length === 3);
  });
  check('Seeded tray generation is deterministic', () => { assert(JSON.stringify(generateTray(emptyBoard(), 777)) === JSON.stringify(generateTray(emptyBoard(), 777))); });
  check('Daily starting pieces are deterministic', () => { const a = newGame('daily', 0, '2026-07-01'), b = newGame('daily', 0, '2026-07-01'); assert(JSON.stringify(a.pieces) === JSON.stringify(b.pieces)); });
  check('Generated trays are fair on crowded boards', () => {
    const b = emptyBoard(); for (let i = 0; i < 48; i++) b[i] = i % 7;
    for (let seed = 1; seed <= 40; seed++) assert(generateTray(b, seed).pieces.every(p => hasLegalPlacement(b, p)), `Impossible generated piece at seed ${seed}`);
  });
  check('Game over is detected when no remaining shape fits', () => { const b: Board = Array(64).fill(1); b[0] = null; const p = testPiece([[0, 0], [1, 0]]); assert(isGameOver(b, [p, p, null])); });
  check('A legal remaining single prevents game over', () => { const b: Board = Array(64).fill(1); b[0] = null; assert(!isGameOver(b, [single, null, null])); });
  check('Revive creates a fair landing zone for every shape', () => { const g = { ...testGame(Array(64).fill(1)), over: true }; const r = reviveGame(g); assert(r && r.revived && !r.over && SHAPES.every(s => hasLegalPlacement(r.board, s)) && r.score === g.score && r.combo === 0); });
  check('Revive is limited to once per game', () => { const g = { ...testGame(Array(64).fill(1)), over: true, revived: true }; assert(reviveGame(g) === null && reviveGame(testGame()) === null); });
  check('Normal moves grant coins and XP offline', () => { const r = placePiece(testGame(almostRows(1)), 0, 0, 7); assert(r && r.coins > 0 && r.xp > 0 && r.game.coinsEarned === r.coins && r.game.xpEarned === r.xp); });
  check('Snapshot serialization preserves the board and tray', () => { const g = placePiece(testGame(), 0, 0, 0)!.game; const restored = JSON.parse(JSON.stringify(g)) as Game; assert(JSON.stringify(restored) === JSON.stringify(g)); });
  check('Level and XP boundaries are correct', () => { assert(levelInfo(0).level === 1 && levelInfo(249).level === 1 && levelInfo(250).level === 2 && levelInfo(750).level === 3); });
  check('Level-up unlocks are visual and free', () => { const p = applyLevelUnlocks({ ...defaultProfile(), xp: 250 }); assert(p.unlocked.includes('skin:ice') && p.coins === defaultProfile().coins); });
  check('Cosmetic purchases deduct exactly the listed price', () => { const c = COSMETICS.find(c => c.category === 'skin' && c.id === 'ice')!; const p = purchaseCosmetic(defaultProfile(), c); assert(p && p.coins === 100 && p.selected.skin === 'ice' && p.unlocked.includes('skin:ice')); });
  check('Owned cosmetics can be equipped without paying again', () => { const c = COSMETICS.find(c => c.category === 'skin' && c.id === 'ice')!; const p = purchaseCosmetic(defaultProfile(), c)!; const again = purchaseCosmetic(p, c); assert(again?.coins === p.coins); });
  check('Insufficient coin balances cannot buy cosmetics', () => { const c = COSMETICS.find(c => c.id === 'fire')!; assert(purchaseCosmetic(defaultProfile(), c) === null); });
  check('Every block skin has a complete original palette', () => { assert(COSMETICS.filter(c => c.category === 'skin').every(c => PALETTES[c.id]?.length === 7 && PALETTES[c.id].every(color => /^#[0-9a-f]{6}$/i.test(color)))); });
  check('Daily reward is granted exactly once', () => { const day = utcDay(); const p = { ...defaultProfile(), daily: { [day]: { progress: dailyMission(day).target, completed: true, claimed: false } } }; const claimed = claimDailyReward(p, day); assert(claimed && claimed.coins === p.coins + 150 && claimed.xp === 250 && claimDailyReward(claimed, day) === null); });
  check('Incomplete and expired daily rewards cannot be claimed', () => { assert(claimDailyReward(defaultProfile()) === null); const p = { ...defaultProfile(), daily: { '2000-01-01': { progress: 99999, completed: true, claimed: false } } }; assert(claimDailyReward(p, '2000-01-01') === null); });
  check('Daily completion is counted once despite repeated moves', () => { const day = utcDay(), m = dailyMission(day); const g = { ...testGame(), mode: 'daily' as const, dailyDate: day, [m.metric]: m.target }; const p = advanceDaily(defaultProfile(), g); const again = advanceDaily(p, g); assert(p.daily[day].completed && p.stats.dailyCompleted === 1 && again.stats.dailyCompleted === 1); });
  check('Achievement rewards cannot be claimed twice', () => { const a = ACHIEVEMENTS[0]; const p = defaultProfile(); p.stats.lines = 1; const earned = claimAchievement(p, a); assert(earned && earned.coins === p.coins + 25 && claimAchievement(earned, a) === null); });
  check('Locked achievements cannot grant a reward', () => { assert(claimAchievement(defaultProfile(), ACHIEVEMENTS[0]) === null); });
  check('Original catalog includes all requested cosmetics and 20+ achievements', () => { assert(ACHIEVEMENTS.length >= 20 && COSMETICS.filter(c => c.category === 'skin').length === 8 && COSMETICS.filter(c => c.category === 'theme').length === 5 && COSMETICS.filter(c => c.category === 'effect').length === 4); });
  check('Completed-line detection does not mutate the board', () => { const b = almostRows(2), snapshot = JSON.stringify(b); completedLines(b); assert(JSON.stringify(b) === snapshot); });
  return results;
}
