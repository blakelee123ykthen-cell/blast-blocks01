import { Capacitor } from '@capacitor/core';
import { AdMob, BannerAdSize, BannerAdPosition, RewardAdPluginEvents, InterstitialAdPluginEvents } from '@capacitor-community/admob';
import { appConfig } from '../config';

// No simulated ads: browsers, offline devices, denied consent, and empty inventory
// all return false. No SDK initialization or ad display happens during app launch.
class AdvertisementService {
  private initialized = false;
  private initializing: Promise<boolean> | null = null;
  private rewardedReady = false;
  private loadedAt = 0;
  private loadingReward = false;
  private showing = false;
  private finishedGames = 0;
  private lastInterstitial = 0;
  private launchedAt = Date.now();
  private personalized = false;
  get supported() { return appConfig.ads.enabled && Capacitor.isNativePlatform() && navigator.onLine; }
  get rewardAvailable() { return this.supported && this.rewardedReady && Date.now() - this.loadedAt < 45 * 60_000 && !this.showing; }
  setPersonalization(value: boolean) { this.personalized = value; }
  private id(kind: 'rewarded' | 'interstitial' | 'banner'): string { return appConfig.ads.testMode ? appConfig.ads.test[kind] : appConfig.ads.production[kind]; }
  private async initialize(): Promise<boolean> {
    if (!this.supported) return false;
    if (this.initialized) return true;
    if (this.initializing) return this.initializing;
    this.initializing = (async () => {
      try {
        await AdMob.initialize({ initializeForTesting: appConfig.ads.testMode });
        let consent = await AdMob.requestConsentInfo();
        if (!consent.canRequestAds && consent.isConsentFormAvailable) consent = await AdMob.showConsentForm();
        if (!consent.canRequestAds) return false;
        this.initialized = true; return true;
      } catch { return false; }
      finally { this.initializing = null; }
    })();
    return this.initializing;
  }
  async prepareReward(): Promise<boolean> {
    if (this.rewardAvailable) return true;
    if (this.loadingReward || !this.supported || !this.id('rewarded')) return false;
    this.loadingReward = true; this.rewardedReady = false;
    try {
      if (!await this.initialize()) return false;
      await AdMob.prepareRewardVideoAd({ adId: this.id('rewarded'), isTesting: appConfig.ads.testMode, npa: !this.personalized, immersiveMode: true });
      this.loadedAt = Date.now(); this.rewardedReady = true; return true;
    } catch { this.rewardedReady = false; return false; }
    finally { this.loadingReward = false; }
  }
  async showReward(): Promise<boolean> {
    if (!this.rewardAvailable) return false;
    this.rewardedReady = false; this.showing = true;
    let earned = false, finished = false;
    let resolveOutcome!: (value: boolean) => void;
    const outcome = new Promise<boolean>(resolve => { resolveOutcome = resolve; });
    const finish = (value: boolean) => { if (!finished) { finished = true; resolveOutcome(value); } };
    const handles: { remove: () => Promise<void> }[] = [];
    const timeout = window.setTimeout(() => finish(false), 180_000);
    try {
      handles.push(await AdMob.addListener(RewardAdPluginEvents.Rewarded, () => { earned = true; }));
      handles.push(await AdMob.addListener(RewardAdPluginEvents.Dismissed, () => { window.setTimeout(() => finish(earned), 100); }));
      handles.push(await AdMob.addListener(RewardAdPluginEvents.FailedToShow, () => finish(false)));
      // Wait for dismissal as well as a reward; never resume gameplay behind an ad.
      void AdMob.showRewardVideoAd().then(reward => { if (reward?.amount > 0) earned = true; }).catch(() => finish(false));
      return await outcome;
    } catch { return false; }
    finally {
      clearTimeout(timeout); this.showing = false;
      await Promise.all(handles.map(handle => handle.remove().catch(() => {})));
    }
  }
  gameFinished() { this.finishedGames++; }
  async naturalBreak(): Promise<void> {
    const now = Date.now();
    if (!this.supported || this.showing || this.finishedGames < 3 || now - this.launchedAt < 120_000 || now - this.lastInterstitial < appConfig.ads.minimumInterstitialIntervalMs || !this.id('interstitial')) return;
    const handles: { remove: () => Promise<void> }[] = [];
    let timeout: number | undefined;
    try {
      if (!await this.initialize()) return;
      await AdMob.prepareInterstitial({ adId: this.id('interstitial'), isTesting: appConfig.ads.testMode, npa: !this.personalized });
      let resolveDismissed!: () => void;
      const dismissed = new Promise<void>(resolve => { resolveDismissed = resolve; });
      handles.push(await AdMob.addListener(InterstitialAdPluginEvents.Dismissed, () => resolveDismissed()));
      handles.push(await AdMob.addListener(InterstitialAdPluginEvents.FailedToShow, () => resolveDismissed()));
      this.lastInterstitial = now; this.finishedGames = 0; this.showing = true;
      timeout = window.setTimeout(resolveDismissed, 180_000);
      void AdMob.showInterstitial().catch(() => resolveDismissed());
      await dismissed;
    } catch { /* Optional ads never block gameplay. */ }
    finally {
      if (timeout !== undefined) clearTimeout(timeout);
      this.showing = false;
      await Promise.all(handles.map(handle => handle.remove().catch(() => {})));
    }
  }
  async menuBanner(): Promise<void> {
    if (!appConfig.ads.bannerEnabled || !this.initialized || !this.supported || !this.id('banner')) return;
    try { await AdMob.showBanner({ adId: this.id('banner'), adSize: BannerAdSize.BANNER, position: BannerAdPosition.BOTTOM_CENTER, isTesting: appConfig.ads.testMode, npa: !this.personalized }); } catch { /* unavailable */ }
  }
  async hideBanner(): Promise<void> { if (this.initialized) { try { await AdMob.hideBanner(); } catch { /* unavailable */ } } }
  async privacyOptions(): Promise<boolean> { try { if (!await this.initialize()) return false; await AdMob.showPrivacyOptionsForm(); this.rewardedReady = false; return true; } catch { return false; } }
}
export const ads = new AdvertisementService();
