export const BOARD_SIZE = 8;
export type Coordinate = [number, number];
export type Board = (number | null)[];
export type Mode = 'endless' | 'daily';
export interface Shape { name: string; cells: Coordinate[]; weight: number }
export interface Piece { id: string; name: string; cells: Coordinate[]; color: number }
export interface Game {
  id: string; board: Board; pieces: (Piece | null)[]; score: number; combo: number;
  maxCombo: number; maxClear: number; lines: number; moves: number; blocks: number;
  coinsEarned: number; xpEarned: number; rng: number; mode: Mode; dailyDate: string;
  startedAt: number; bestAtStart: number; revived: boolean; over: boolean; settled: boolean;
}
export interface MoveResult {
  game: Game; beforeClear: Board; placed: number[]; cleared: number[];
  rows: number[]; columns: number[]; lineCount: number; points: number; coins: number; xp: number;
}

function shape(name: string, matrix: string[], weight = 1): Shape {
  const cells: Coordinate[] = [];
  matrix.forEach((line, y) => [...line].forEach((cell, x) => { if (cell === '#') cells.push([x, y]); }));
  return { name, cells, weight };
}
export const SHAPES: Shape[] = [
  shape('Spark', ['#'], .45),
  shape('Duo', ['##'], 1.5), shape('Upright duo', ['#', '#'], 1.5),
  shape('Orbit', ['###'], 1.5), shape('Upright orbit', ['#', '#', '#'], 1.5),
  shape('Comet', ['####'], .9), shape('Upright comet', ['#', '#', '#', '#'], .9),
  shape('Meteor', ['#####'], .55), shape('Upright meteor', ['#', '#', '#', '#', '#'], .55),
  shape('Satellite', ['##', '##'], 1.5),
  shape('Little elbow', ['#.', '##'], 1.2), shape('Little reverse elbow', ['.#', '##'], 1.2),
  shape('Little corner', ['##', '#.'], 1.2), shape('Little reverse corner', ['##', '.#'], 1.2),
  shape('Lander', ['#.', '#.', '##']), shape('Reverse lander', ['.#', '.#', '##']),
  shape('Lander east', ['###', '#..']), shape('Lander west', ['###', '..#']),
  shape('Lander north', ['##', '.#', '.#']), shape('Lander south', ['##', '#.', '#.']),
  shape('Wide lander', ['#..', '###']), shape('Wide reverse lander', ['..#', '###']),
  shape('Signal', ['###', '.#.']), shape('Rising signal', ['.#.', '###']),
  shape('Signal east', ['#.', '##', '#.']), shape('Signal west', ['.#', '##', '.#']),
  shape('Drift', ['.##', '##.']), shape('Reverse drift', ['##.', '.##']),
  shape('Rising drift', ['#.', '##', '.#']), shape('Rising reverse drift', ['.#', '##', '#.']),
  shape('North star', ['.#.', '###', '.#.'], .8),
  shape('Crescent', ['#.#', '###'], .8), shape('Rising crescent', ['##', '#.', '##'], .8),
  shape('Stairway', ['#..', '##.', '.##'], .8), shape('Reverse stairway', ['..#', '.##', '##.'], .8),
  shape('Constellation', ['###', '#..', '#..'], .7),
  shape('Reverse constellation', ['###', '..#', '..#'], .7),
  shape('Shuttle', ['##', '##', '#.'], .9), shape('Reverse shuttle', ['##', '##', '.#'], .9),
  shape('Solar sail', ['###', '###'], .45), shape('Tall solar sail', ['##', '##', '##'], .45),
  shape('Beacon', ['##.', '.##', '.#.'], .7),
];

export function emptyBoard(): Board { return Array(64).fill(null); }
export function dimensions(piece: Pick<Piece, 'cells'>) {
  return { width: Math.max(...piece.cells.map(c => c[0])) + 1, height: Math.max(...piece.cells.map(c => c[1])) + 1 };
}
export function canPlace(board: Board, piece: Pick<Piece, 'cells'>, row: number, col: number): boolean {
  return piece.cells.length > 0 && piece.cells.every(([x, y]) => {
    const r = row + y, c = col + x;
    return r >= 0 && r < 8 && c >= 0 && c < 8 && board[r * 8 + c] === null;
  });
}
export function legalPositions(board: Board, piece: Pick<Piece, 'cells'>): Coordinate[] {
  const result: Coordinate[] = [];
  const { width, height } = dimensions(piece);
  for (let r = 0; r <= 8 - height; r++) for (let c = 0; c <= 8 - width; c++) {
    if (canPlace(board, piece, r, c)) result.push([c, r]);
  }
  return result;
}
export function hasLegalPlacement(board: Board, piece: Pick<Piece, 'cells'>): boolean {
  const { width, height } = dimensions(piece);
  for (let r = 0; r <= 8 - height; r++) for (let c = 0; c <= 8 - width; c++) {
    if (canPlace(board, piece, r, c)) return true;
  }
  return false;
}
export function completedLines(board: Board) {
  const rows: number[] = [], columns: number[] = [], indices = new Set<number>();
  for (let i = 0; i < 8; i++) {
    if (Array.from({ length: 8 }, (_, j) => board[i * 8 + j]).every(v => v !== null)) rows.push(i);
    if (Array.from({ length: 8 }, (_, j) => board[j * 8 + i]).every(v => v !== null)) columns.push(i);
  }
  rows.forEach(r => { for (let c = 0; c < 8; c++) indices.add(r * 8 + c); });
  columns.forEach(c => { for (let r = 0; r < 8; r++) indices.add(r * 8 + c); });
  return { rows, columns, indices: [...indices] };
}
export function hashSeed(value: string): number {
  let h = 2166136261;
  for (const c of value) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function nextRandom(seed: number): [number, number] {
  const state = (seed + 0x6D2B79F5) >>> 0;
  let t = Math.imul(state ^ (state >>> 15), 1 | state);
  t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
  return [((t ^ (t >>> 14)) >>> 0) / 4294967296, state];
}
export function generateTray(board: Board, seed: number): { pieces: Piece[]; rng: number } {
  // Every generated piece fits the current board. Later placement choices still matter.
  // This avoids deliberately impossible trays while keeping the game strategic.
  const fitting = SHAPES.filter(s => hasLegalPlacement(board, s));
  const candidates = fitting.length ? fitting : SHAPES;
  const pieces: Piece[] = [];
  let rng = seed;
  for (let i = 0; i < 3; i++) {
    let value: number;
    [value, rng] = nextRandom(rng);
    const totalWeight = candidates.reduce((sum, s) => sum + s.weight, 0);
    let pick = value * totalWeight;
    let selected = candidates[candidates.length - 1];
    for (const candidate of candidates) { pick -= candidate.weight; if (pick <= 0) { selected = candidate; break; } }
    [value, rng] = nextRandom(rng);
    pieces.push({ id: `${rng.toString(36)}-${i}`, name: selected.name, cells: selected.cells.map(c => [...c] as Coordinate), color: Math.floor(value * 7) });
  }
  return { pieces, rng };
}
export function utcDay(): string { return new Date().toISOString().slice(0, 10); }
export function newGame(mode: Mode, best = 0, day = utcDay(), seed?: number): Game {
  const rngSeed = seed ?? (mode === 'daily' ? hashSeed(`orbit-daily-${day}`) : Math.floor(Math.random() * 4294967296));
  const board = emptyBoard();
  const tray = generateTray(board, rngSeed);
  return {
    id: `${Date.now().toString(36)}-${rngSeed.toString(36)}`, board, pieces: tray.pieces, rng: tray.rng,
    score: 0, combo: 0, maxCombo: 0, maxClear: 0, lines: 0, moves: 0, blocks: 0,
    coinsEarned: 0, xpEarned: 0, mode, dailyDate: mode === 'daily' ? day : '',
    startedAt: Date.now(), bestAtStart: best, revived: false, over: false, settled: false,
  };
}
export function lineBonus(count: number): number {
  return [0, 100, 250, 500, 1000][count] ?? 1000 + (count - 4) * 600;
}
export function isGameOver(board: Board, pieces: (Piece | null)[]): boolean {
  return !pieces.some(piece => piece !== null && hasLegalPlacement(board, piece));
}
export function placePiece(game: Game, index: number, row: number, col: number): MoveResult | null {
  const piece = game.pieces[index];
  if (game.over || !piece || !canPlace(game.board, piece, row, col)) return null;
  const beforeClear = [...game.board];
  const placed = piece.cells.map(([x, y]) => (row + y) * 8 + col + x);
  placed.forEach(i => { beforeClear[i] = piece.color; });
  const lines = completedLines(beforeClear);
  const lineCount = lines.rows.length + lines.columns.length;
  const combo = lineCount ? game.combo + 1 : 0;
  const points = piece.cells.length * 10 + lineBonus(lineCount) * Math.max(1, combo);
  const coins = Math.floor(piece.cells.length / 4) + lineCount * 4 + (lineCount ? Math.max(0, combo - 1) : 0);
  const xp = piece.cells.length + lineCount * 12 + (lineCount ? combo * 4 : 0);
  const board = [...beforeClear];
  lines.indices.forEach(i => { board[i] = null; });
  let pieces = game.pieces.map((p, i) => i === index ? null : p);
  let rng = game.rng;
  if (pieces.every(p => p === null)) { const tray = generateTray(board, rng); pieces = tray.pieces; rng = tray.rng; }
  const next: Game = {
    ...game, board, pieces, rng, score: game.score + points, combo, maxCombo: Math.max(game.maxCombo, combo),
    maxClear: Math.max(game.maxClear, lineCount), lines: game.lines + lineCount, moves: game.moves + 1,
    blocks: game.blocks + piece.cells.length, coinsEarned: game.coinsEarned + coins, xpEarned: game.xpEarned + xp,
    over: isGameOver(board, pieces),
  };
  return { game: next, beforeClear, placed, cleared: lines.indices, rows: lines.rows, columns: lines.columns, lineCount, points, coins, xp };
}
export function reviveGame(game: Game): Game | null {
  if (!game.over || game.revived) return null;
  const board = [...game.board];
  // A 5×5 empty landing zone guarantees a fair second chance for every shape.
  for (let r = 1; r <= 5; r++) for (let c = 1; c <= 5; c++) board[r * 8 + c] = null;
  return { ...game, board, combo: 0, revived: true, over: false };
}

export const MENU_BOARD: Board = (() => {
  const b = emptyBoard();
  const groups: [number, number[]][] = [
    [2, [0, 1, 8]], [1, [5, 6, 7, 13]], [0, [18, 19, 20, 27]],
    [4, [32, 33, 40, 48]], [3, [36, 37, 44, 45]], [2, [50, 51, 52, 53]],
    [5, [47, 55, 62, 63]], [0, [57, 58]],
  ];
  groups.forEach(([color, cells]) => cells.forEach(i => { b[i] = color; }));
  return b;
})();
export const MENU_PIECES: Piece[] = [
  { id: 'menu-a', name: 'Signal', color: 0, cells: [[0, 0], [1, 0], [2, 0], [1, 1]] },
  { id: 'menu-b', name: 'Satellite', color: 1, cells: [[0, 0], [1, 0], [0, 1], [1, 1]] },
  { id: 'menu-c', name: 'Lander', color: 2, cells: [[0, 0], [0, 1], [0, 2], [1, 2]] },
];
