import { hashSeed, utcDay, type Game } from './engine';

export const SAVE_KEY = 'orbit-block-puzzle-v1';
export type CosmeticCategory = 'skin' | 'theme' | 'effect';
export interface Cosmetic { id: string; name: string; category: CosmeticCategory; price: number; level?: number; subtitle: string }
export interface Settings { sound: boolean; music: boolean; haptics: boolean; reducedMotion: boolean; personalizedAds: boolean }
export interface Stats { games: number; lines: number; blocks: number; clearMoves: number; maxCombo: number; maxClear: number; perfectClears: number; dailyCompleted: number; records: number; revives: number; totalScore: number }
export interface DailyStatus { progress: number; completed: boolean; claimed: boolean }
export interface Profile {
  version: 1; best: number; coins: number; xp: number; unlocked: string[];
  selected: { skin: string; theme: string; effect: string }; settings: Settings; stats: Stats;
  claimedAchievements: string[]; daily: Record<string, DailyStatus>; lastSession: Game | null;
  seenTutorial: boolean; adBonus: { date: string; count: number };
}
export const COSMETICS: Cosmetic[] = [
  { id: 'neon', name: 'Neon', category: 'skin', price: 0, subtitle: 'Your original cosmic glow' },
  { id: 'fire', name: 'Fire', category: 'skin', price: 300, subtitle: 'A little extra heat' },
  { id: 'ice', name: 'Ice', category: 'skin', price: 150, level: 2, subtitle: 'Cool, calm, collected' },
  { id: 'galaxy', name: 'Galaxy', category: 'skin', price: 450, level: 5, subtitle: 'Written in the stars' },
  { id: 'candy', name: 'Candy', category: 'skin', price: 250, subtitle: 'Something sweet' },
  { id: 'chrome', name: 'Chrome', category: 'skin', price: 650, level: 10, subtitle: 'A polished perspective' },
  { id: 'cyber', name: 'Cyber', category: 'skin', price: 400, level: 7, subtitle: 'A brighter future' },
  { id: 'rainbow', name: 'Rainbow', category: 'skin', price: 800, subtitle: 'Every color in your orbit' },
  { id: 'space', name: 'Space', category: 'theme', price: 0, subtitle: 'Your home among the stars' },
  { id: 'cyber', name: 'Cyber', category: 'theme', price: 350, level: 6, subtitle: 'Meet the electric grid' },
  { id: 'ocean', name: 'Ocean', category: 'theme', price: 200, level: 3, subtitle: 'Find your calm' },
  { id: 'sunset', name: 'Sunset', category: 'theme', price: 300, subtitle: 'One more golden hour' },
  { id: 'midnight', name: 'Midnight', category: 'theme', price: 250, subtitle: 'Quiet, focused, timeless' },
  { id: 'lightning', name: 'Lightning', category: 'effect', price: 300, subtitle: 'A flash of brilliance' },
  { id: 'star-burst', name: 'Star Burst', category: 'effect', price: 0, subtitle: 'Make a little stardust' },
  { id: 'pixel-explosion', name: 'Pixel Explosion', category: 'effect', price: 250, level: 4, subtitle: 'A pixel-perfect celebration' },
  { id: 'cosmic-burst', name: 'Cosmic Burst', category: 'effect', price: 500, level: 8, subtitle: 'Your own small supernova' },
];
export const PALETTES: Record<string, string[]> = {
  neon: ['#9a72f7', '#45d6c4', '#f5a15a', '#e477c3', '#638cf3', '#81cc85', '#ebce68'],
  fire: ['#ff905b', '#f3bc55', '#ec615c', '#ed7970', '#df515f', '#ffaf68', '#ffd17c'],
  ice: ['#a4dbff', '#72e3e5', '#72bafa', '#b6b5f9', '#5aa7ea', '#a4f1e2', '#dcf4ff'],
  galaxy: ['#b58afd', '#6d88ed', '#e17ccf', '#8670d8', '#b1b6ff', '#d19cfc', '#767df3'],
  candy: ['#f58aba', '#92e5de', '#ffc47e', '#c59cfb', '#8db3fb', '#c8e792', '#ffe68b'],
  chrome: ['#d2dbe8', '#91a7bc', '#a7b5cb', '#edf1f8', '#7c96b0', '#b0c7c8', '#c8cadb'],
  cyber: ['#ed62df', '#45e6d5', '#8c70ff', '#ff91dd', '#539ded', '#87f0bc', '#d4ed79'],
  rainbow: ['#f57885', '#ffaf6d', '#efda66', '#81d596', '#69bbf0', '#a785f8', '#f082cd'],
};
export function blockColor(index: number, skin = 'neon'): string { return (PALETTES[skin] ?? PALETTES.neon)[index % 7]; }
export function levelInfo(xp: number) {
  let level = 1;
  while (level < 99 && xp >= 125 * level * (level + 1)) level++;
  const floor = 125 * (level - 1) * level;
  const ceiling = 125 * level * (level + 1);
  const titles = ['Space cadet', 'Orbit explorer', 'Star seeker', 'Comet rider', 'Space captain', 'Cosmic voyager', 'Nova navigator', 'Galaxy guardian', 'Stellar ace', 'Orbit legend'];
  return { level, current: xp - floor, required: ceiling - floor, progress: Math.min(1, (xp - floor) / (ceiling - floor)), title: titles[Math.min(level - 1, 9)] };
}
export function applyLevelUnlocks(profile: Profile): Profile {
  const level = levelInfo(profile.xp).level;
  const unlocked = new Set(profile.unlocked);
  COSMETICS.filter(c => c.level && level >= c.level).forEach(c => unlocked.add(`${c.category}:${c.id}`));
  return { ...profile, unlocked: [...unlocked] };
}
export function defaultProfile(): Profile {
  return {
    version: 1, best: 0, coins: 250, xp: 0,
    unlocked: ['skin:neon', 'theme:space', 'effect:star-burst'],
    selected: { skin: 'neon', theme: 'space', effect: 'star-burst' },
    settings: { sound: true, music: false, haptics: true, reducedMotion: false, personalizedAds: false },
    stats: { games: 0, lines: 0, blocks: 0, clearMoves: 0, maxCombo: 0, maxClear: 0, perfectClears: 0, dailyCompleted: 0, records: 0, revives: 0, totalScore: 0 },
    claimedAchievements: [], daily: {}, lastSession: null, seenTutorial: false, adBonus: { date: '', count: 0 },
  };
}
function validNumber(value: unknown, fallback = 0): number { return typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : fallback; }
function validSession(value: unknown): value is Game {
  if (!value || typeof value !== 'object') return false;
  const g = value as Game;
  return Array.isArray(g.board) && g.board.length === 64 && g.board.every(c => c === null || Number.isInteger(c) && c >= 0 && c < 7)
    && Array.isArray(g.pieces) && g.pieces.length === 3 && g.pieces.every(p => p === null || (typeof p.id === 'string' && Number.isInteger(p.color) && p.color >= 0 && p.color < 7 && Array.isArray(p.cells) && p.cells.length > 0 && p.cells.every(c => Array.isArray(c) && c.length === 2 && c.every(n => Number.isInteger(n) && n >= 0 && n < 5))))
    && [g.score, g.rng, g.combo, g.maxCombo, g.maxClear, g.lines, g.moves, g.blocks, g.coinsEarned, g.xpEarned, g.startedAt, g.bestAtStart].every(n => typeof n === 'number' && Number.isFinite(n) && n >= 0)
    && typeof g.over === 'boolean' && typeof g.revived === 'boolean' && typeof g.settled === 'boolean'
    && typeof g.dailyDate === 'string' && typeof g.id === 'string' && (g.mode === 'endless' || g.mode === 'daily');
}
export function loadProfile(): Profile {
  const base = defaultProfile();
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return base;
    const p = JSON.parse(raw) as Profile;
    if (p.version !== 1) return base;
    const allIds = new Set(COSMETICS.map(c => `${c.category}:${c.id}`));
    const unlocked = [...new Set([...base.unlocked, ...(Array.isArray(p.unlocked) ? p.unlocked.filter(id => allIds.has(id)) : [])])];
    const selected = { ...base.selected };
    (['skin', 'theme', 'effect'] as CosmeticCategory[]).forEach(category => { if (p.selected && unlocked.includes(`${category}:${p.selected[category]}`)) selected[category] = p.selected[category]; });
    const settings = { ...base.settings };
    (Object.keys(settings) as (keyof Settings)[]).forEach(k => { if (typeof p.settings?.[k] === 'boolean') settings[k] = p.settings[k]; });
    const stats = { ...base.stats };
    (Object.keys(stats) as (keyof Stats)[]).forEach(k => { stats[k] = validNumber(p.stats?.[k]); });
    const daily: Record<string, DailyStatus> = {};
    if (p.daily && typeof p.daily === 'object') Object.entries(p.daily).forEach(([day, d]) => { if (/^\d{4}-\d{2}-\d{2}$/.test(day) && d && typeof d === 'object') daily[day] = { progress: validNumber(d.progress), completed: d.completed === true, claimed: d.claimed === true }; });
    return applyLevelUnlocks({ ...base, best: validNumber(p.best), coins: validNumber(p.coins, 250), xp: validNumber(p.xp), unlocked, selected, settings, stats, daily,
      claimedAchievements: Array.isArray(p.claimedAchievements) ? p.claimedAchievements.filter(id => typeof id === 'string') : [],
      lastSession: validSession(p.lastSession) ? p.lastSession : null, seenTutorial: p.seenTutorial === true,
      adBonus: { date: typeof p.adBonus?.date === 'string' ? p.adBonus.date : '', count: validNumber(p.adBonus?.count) },
    });
  } catch { return base; }
}
export function saveProfile(profile: Profile): boolean {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(profile)); return true; } catch { return false; }
}

export type DailyMetric = 'score' | 'lines' | 'maxCombo' | 'maxClear';
export interface DailyMission { date: string; title: string; description: string; metric: DailyMetric; target: number; coins: number; xp: number }
export function dailyMission(date = utcDay()): DailyMission {
  const missions: Pick<DailyMission, 'title' | 'description' | 'metric' | 'target'>[] = [
    { title: 'Star chaser', description: 'Clear 20 lines in one run.', metric: 'lines', target: 20 },
    { title: 'Cosmic climb', description: 'Reach 5,000 points in one run.', metric: 'score', target: 5000 },
    { title: 'Stay in orbit', description: 'Reach a 10× clearing streak.', metric: 'maxCombo', target: 10 },
    { title: 'Triple stardust', description: 'Clear 3 lines in a single move.', metric: 'maxClear', target: 3 },
    { title: 'Aim a little higher', description: 'Reach 2,500 points in one run.', metric: 'score', target: 2500 },
  ];
  return { ...missions[hashSeed(date) % missions.length], date, coins: 150, xp: 250 };
}
export function advanceDaily(profile: Profile, game: Game): Profile {
  if (game.mode !== 'daily' || game.dailyDate !== utcDay()) return profile;
  const mission = dailyMission(game.dailyDate);
  const previous = profile.daily[game.dailyDate] ?? { progress: 0, completed: false, claimed: false };
  const progress = Math.max(previous.progress, game[mission.metric]);
  const completed = progress >= mission.target;
  return { ...profile, daily: { ...profile.daily, [game.dailyDate]: { ...previous, progress, completed } },
    stats: { ...profile.stats, dailyCompleted: profile.stats.dailyCompleted + (!previous.completed && completed ? 1 : 0) } };
}

export function claimDailyReward(profile: Profile, date = utcDay()): Profile | null {
  const status = profile.daily[date];
  if (date !== utcDay() || !status?.completed || status.claimed) return null;
  const mission = dailyMission(date);
  return applyLevelUnlocks({ ...profile, coins: profile.coins + mission.coins, xp: profile.xp + mission.xp,
    daily: { ...profile.daily, [date]: { ...status, claimed: true } } });
}
export function purchaseCosmetic(profile: Profile, cosmetic: Cosmetic): Profile | null {
  const key = `${cosmetic.category}:${cosmetic.id}`;
  const owned = profile.unlocked.includes(key);
  if (!owned && profile.coins < cosmetic.price) return null;
  return { ...profile, coins: profile.coins - (owned ? 0 : cosmetic.price), unlocked: owned ? profile.unlocked : [...profile.unlocked, key],
    selected: { ...profile.selected, [cosmetic.category]: cosmetic.id } };
}
export function claimAchievement(profile: Profile, achievement: Achievement): Profile | null {
  if (profile.claimedAchievements.includes(achievement.id) || achievement.value(profile) < achievement.target) return null;
  return { ...profile, coins: profile.coins + achievement.coins,
    claimedAchievements: [...profile.claimedAchievements, achievement.id],
    unlocked: achievement.cosmetic ? [...new Set([...profile.unlocked, achievement.cosmetic])] : profile.unlocked };
}

export interface Achievement {
  id: string; name: string; description: string; target: number; coins: number; cosmetic?: string;
  value: (profile: Profile) => number; icon: 'blast' | 'blocks' | 'combo' | 'score' | 'play' | 'level' | 'daily' | 'collection';
}
export const ACHIEVEMENTS: Achievement[] = [
  { id: 'first-blast', name: 'First blast', description: 'Clear your first line', target: 1, coins: 25, value: p => p.stats.lines, icon: 'blast' },
  { id: 'building-blocks', name: 'Building blocks', description: 'Place 25 blocks', target: 25, coins: 30, value: p => p.stats.blocks, icon: 'blocks' },
  { id: 'line-breaker', name: 'Line breaker', description: 'Clear 100 lines', target: 100, coins: 100, value: p => p.stats.lines, icon: 'blast' },
  { id: 'orbit-architect', name: 'Orbit architect', description: 'Clear 500 lines', target: 500, coins: 300, value: p => p.stats.lines, icon: 'blast' },
  { id: 'good-things', name: 'Good things come in threes', description: 'Reach a 3× streak', target: 3, coins: 40, value: p => p.stats.maxCombo, icon: 'combo' },
  { id: 'in-the-flow', name: 'In the flow', description: 'Reach a 6× streak', target: 6, coins: 80, value: p => p.stats.maxCombo, icon: 'combo' },
  { id: 'combo-king', name: 'Combo king', description: 'Reach a 10× streak', target: 10, coins: 200, value: p => p.stats.maxCombo, icon: 'combo' },
  { id: 'double-take', name: 'Double take', description: 'Clear 2 lines together', target: 2, coins: 40, value: p => p.stats.maxClear, icon: 'blast' },
  { id: 'triple-threat', name: 'Triple threat', description: 'Clear 3 lines together', target: 3, coins: 120, value: p => p.stats.maxClear, icon: 'blast' },
  { id: 'supernova', name: 'Supernova', description: 'Clear 4 lines together', target: 4, coins: 200, value: p => p.stats.maxClear, icon: 'blast' },
  { id: 'clean-slate', name: 'Clean slate', description: 'Empty the entire board with a clear', target: 1, coins: 75, value: p => p.stats.perfectClears, icon: 'blocks' },
  { id: 'high-score', name: 'High flyer', description: 'Reach 5,000 points', target: 5000, coins: 150, value: p => p.best, icon: 'score' },
  { id: 'block-master', name: 'Block master', description: 'Reach 10,000 points', target: 10000, coins: 250, value: p => p.best, icon: 'score' },
  { id: 'legend', name: 'A new constellation', description: 'Reach 50,000 points', target: 50000, coins: 800, cosmetic: 'skin:rainbow', value: p => p.best, icon: 'score' },
  { id: 'first-flight', name: 'First flight', description: 'Start your first game', target: 1, coins: 20, value: p => p.stats.games, icon: 'play' },
  { id: 'regular-orbit', name: 'A regular orbit', description: 'Play 10 games', target: 10, coins: 70, value: p => p.stats.games, icon: 'play' },
  { id: 'puzzle-addict', name: 'Just one more', description: 'Play 50 games', target: 50, coins: 250, value: p => p.stats.games, icon: 'play' },
  { id: 'century', name: 'A hundred little escapes', description: 'Play 100 games', target: 100, coins: 500, value: p => p.stats.games, icon: 'play' },
  { id: 'fresh-orbit', name: 'Fresh orbit', description: 'Reach player level 2', target: 2, coins: 40, value: p => levelInfo(p.xp).level, icon: 'level' },
  { id: 'space-captain', name: 'Space captain', description: 'Reach player level 5', target: 5, coins: 150, value: p => levelInfo(p.xp).level, icon: 'level' },
  { id: 'stellar-ace', name: 'Stellar ace', description: 'Reach player level 10', target: 10, coins: 500, value: p => levelInfo(p.xp).level, icon: 'level' },
  { id: 'daily-dose', name: 'Your daily dose', description: 'Complete a daily challenge', target: 1, coins: 50, value: p => p.stats.dailyCompleted, icon: 'daily' },
  { id: 'seven-stars', name: 'Seven stars', description: 'Complete 7 daily challenges', target: 7, coins: 200, value: p => p.stats.dailyCompleted, icon: 'daily' },
  { id: 'collector', name: 'A colorful collection', description: 'Unlock 7 cosmetics', target: 7, coins: 100, value: p => p.unlocked.length, icon: 'collection' },
  { id: 'thousand-sparks', name: 'A thousand sparks', description: 'Place 1,000 blocks', target: 1000, coins: 100, value: p => p.stats.blocks, icon: 'blocks' },
  { id: 'record-breaker', name: 'Beyond your own stars', description: 'Set 5 new records', target: 5, coins: 100, value: p => p.stats.records, icon: 'score' },
];
