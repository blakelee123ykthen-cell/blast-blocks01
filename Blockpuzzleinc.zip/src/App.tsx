import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent, type KeyboardEvent as ReactKeyboardEvent } from 'react';
import { ArrowLeft, ArrowRight, ArrowUpRight, Award, CalendarDays, Check, ChevronRight, Coins, Flame, Gamepad2, Gift, Grid2X2, Hand, Heart, HelpCircle, Home, Infinity as InfinityIcon, Layers3, Lock, Music2, Pause, Play, RotateCcw, Settings as SettingsIcon, ShieldCheck, ShoppingBag, Sparkles, Star, Target, Trophy, Vibrate, Volume2, VolumeX, WifiOff, X, Zap } from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { App as NativeApp } from '@capacitor/app';
import { Board, BrandMark, OrbitMark, ParticleBurst, PieceShape, SkinSwatch, type PlacementPreview } from './components/GameVisuals';
import { Dialog, Toggle } from './components/Dialog';
import { canPlace, dimensions, hasLegalPlacement, MENU_BOARD, MENU_PIECES, newGame, placePiece, reviveGame, utcDay, type Board as BoardData, type Game, type Mode, type Piece } from './game/engine';
import { ACHIEVEMENTS, COSMETICS, advanceDaily, applyLevelUnlocks, claimAchievement, claimDailyReward, dailyMission, defaultProfile, levelInfo, loadProfile, purchaseCosmetic, saveProfile, type Achievement, type Cosmetic, type CosmeticCategory, type Profile, type Settings } from './game/profile';
import { ads } from './game/ads';
import { audio, haptic } from './game/audio';
import { runCoreChecks } from './game/checks';
import { PhoneInstall, usePhoneInstall } from './components/PhoneInstall';

type View = 'home' | 'play' | 'daily' | 'shop' | 'achievements';
type DialogKind = 'settings' | 'help' | 'pause' | 'restart' | 'privacy' | 'terms' | 'reset' | 'install' | null;
interface Drag {
  index: number; piece: Piece; pointerId: number; x: number; y: number; left: number; top: number;
  offsetX: number; offsetY: number; lift: number; unit: number; gap: number; row: number; col: number;
  valid: boolean; overBoard: boolean; moved: boolean; startX: number; startY: number;
  originLeft: number; originTop: number; originUnit: number;
}
interface ReturnPiece { piece: Piece; left: number; top: number; dx: number; dy: number; unit: number; gap: number; scale: number }
const number = (value: number) => Math.floor(value).toLocaleString('en-US');
const navItems: { view: View; label: string; icon: typeof Gamepad2 }[] = [
  { view: 'home', label: 'Play', icon: Grid2X2 }, { view: 'daily', label: 'Daily challenge', icon: CalendarDays },
  { view: 'shop', label: 'Shop', icon: ShoppingBag }, { view: 'achievements', label: 'Achievements', icon: Trophy },
];
const achievementIcons = { blast: Zap, blocks: Layers3, combo: Flame, score: Trophy, play: Gamepad2, level: Star, daily: CalendarDays, collection: Sparkles };

export default function App() {
  const phoneInstall = usePhoneInstall();
  const [profile, setProfile] = useState<Profile>(loadProfile);
  const profileRef = useRef(profile);
  const [game, setGame] = useState<Game>(() => profile.lastSession ?? newGame('endless', profile.best));
  const gameRef = useRef(game);
  const [view, setView] = useState<View>('home');
  const [dialog, setDialog] = useState<DialogKind>(null);
  const [overOpen, setOverOpen] = useState(false);
  const [today, setToday] = useState(utcDay());
  const [clock, setClock] = useState(Date.now());
  const [online, setOnline] = useState(navigator.onLine);
  const [rewardReady, setRewardReady] = useState(false);
  const [adBusy, setAdBusy] = useState(false);
  const [shopCategory, setShopCategory] = useState<CosmeticCategory>('skin');
  const [achievementFilter, setAchievementFilter] = useState<'all' | 'ready' | 'claimed'>('all');
  const [effectPreview, setEffectPreview] = useState<string | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [hover, setHover] = useState<{ row: number; col: number } | null>(null);
  const [cursor, setCursor] = useState(0);
  const [drag, setDrag] = useState<Drag | null>(null);
  const dragRef = useRef<Drag | null>(null);
  const [returning, setReturning] = useState<ReturnPiece | null>(null);
  const [boardOverlay, setBoardOverlay] = useState<BoardData | null>(null);
  const [clearing, setClearing] = useState<number[]>([]);
  const [placed, setPlaced] = useState<number[]>([]);
  const [burst, setBurst] = useState<{ cells: number[]; board: BoardData; id: number } | null>(null);
  const [comboFeedback, setComboFeedback] = useState<{ text: string; points: number; combo: number; id: number } | null>(null);
  const [shake, setShake] = useState(false);
  const [toast, setToast] = useState<{ id: number; title: string; description?: string } | null>(null);
  const boardRef = useRef<HTMLDivElement>(null);
  const [boardWidth, setBoardWidth] = useState(442);
  useEffect(() => {
    const node = boardRef.current;
    if (!node) return;
    const measure = () => setBoardWidth(node.getBoundingClientRect().width);
    measure();
    if (typeof ResizeObserver !== 'undefined') {
      const observer = new ResizeObserver(measure); observer.observe(node);
      return () => observer.disconnect();
    }
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, [view]);
  const animating = useRef(false);
  const frame = useRef(0);
  const timers = useRef(new Set<number>());
  const pendingMode = useRef<Mode>('endless');
  const storageWarning = useRef(false);
  const navigation = useRef({ view, dialog, overOpen });
  navigation.current = { view, dialog, overOpen };

  const later = useCallback((fn: () => void, delay: number) => {
    const id = window.setTimeout(() => { timers.current.delete(id); fn(); }, delay);
    timers.current.add(id); return id;
  }, []);
  const notify = useCallback((title: string, description?: string) => {
    const id = Date.now() + Math.random();
    setToast({ id, title, description });
    later(() => setToast(current => current?.id === id ? null : current), 3600);
  }, [later]);
  const commit = useCallback((update: (current: Profile) => Profile, celebrate = true) => {
    const before = profileRef.current;
    const next = applyLevelUnlocks(update(before));
    profileRef.current = next; setProfile(next);
    if (!saveProfile(next) && !storageWarning.current) {
      storageWarning.current = true;
      notify('Local storage is unavailable', 'You can play, but this browser cannot save your progress.');
    }
    if (celebrate && levelInfo(next.xp).level > levelInfo(before.xp).level) {
      const unlocks = COSMETICS.filter(c => next.unlocked.includes(`${c.category}:${c.id}`) && !before.unlocked.includes(`${c.category}:${c.id}`));
      notify(`Hello, level ${levelInfo(next.xp).level}!`, unlocks.length ? `${unlocks.map(c => c.name).join(' & ')} unlocked. A little more color for your orbit.` : 'A new orbit. Keep reaching for the stars.');
      audio.play('level');
    } else if (celebrate) {
      const earned = ACHIEVEMENTS.find(a => a.value(next) >= a.target && a.value(before) < a.target && !next.claimedAchievements.includes(a.id));
      if (earned) notify('Achievement unlocked', `${earned.name} — collect your reward in Achievements.`);
    }
    return next;
  }, [notify]);

  useEffect(() => {
    audio.configure(profile.settings.sound, profile.settings.music);
    ads.setPersonalization(profile.settings.personalizedAds);
  }, [profile.settings]);
  useEffect(() => {
    const id = window.setTimeout(() => {
      const failures = runCoreChecks().filter(result => !result.passed);
      if (failures.length) { console.error('Game integrity checks', failures); notify('A game check needs attention', failures[0].error); }
    }, 150);
    return () => clearTimeout(id);
  }, [notify]);
  useEffect(() => { audio.suspend(document.hidden || dialog === 'pause'); }, [dialog]);
  useEffect(() => {
    const visibility = () => {
      saveProfile(profileRef.current);
      audio.suspend(document.hidden);
      if (document.hidden && navigation.current.view === 'play' && !navigation.current.overOpen) setDialog(current => current ?? 'pause');
    };
    const flush = () => { saveProfile(profileRef.current); };
    const connection = () => { setOnline(navigator.onLine); setRewardReady(ads.rewardAvailable); };
    document.addEventListener('visibilitychange', visibility);
    window.addEventListener('pagehide', flush); window.addEventListener('online', connection); window.addEventListener('offline', connection);
    const interval = window.setInterval(() => { setToday(utcDay()); setClock(Date.now()); }, 60_000);
    let disposed = false;
    const listeners: { remove: () => Promise<void> }[] = [];
    if (Capacitor.isNativePlatform()) {
      void (async () => {
        const back = await NativeApp.addListener('backButton', () => {
          const current = navigation.current;
          if (current.dialog) setDialog(null);
          else if (current.overOpen) { setOverOpen(false); setView('home'); }
          else if (current.view === 'play') setDialog('pause');
          else if (current.view !== 'home') setView('home');
          else void NativeApp.exitApp();
        });
        const state = await NativeApp.addListener('appStateChange', ({ isActive }) => {
          saveProfile(profileRef.current); audio.suspend(!isActive);
          if (!isActive && navigation.current.view === 'play' && !navigation.current.overOpen) setDialog(current => current ?? 'pause');
        });
        if (disposed) { void back.remove(); void state.remove(); } else listeners.push(back, state);
      })().catch(() => {});
    }
    return () => {
      disposed = true; listeners.forEach(l => { void l.remove(); }); clearInterval(interval);
      document.removeEventListener('visibilitychange', visibility); window.removeEventListener('pagehide', flush);
      window.removeEventListener('online', connection); window.removeEventListener('offline', connection);
      timers.current.forEach(clearTimeout); cancelAnimationFrame(frame.current);
      audio.suspend(true);
    };
  }, []);
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
    dragRef.current = null; setDrag(null); setSelected(null); setHover(null);
    if (view === 'play') void ads.hideBanner();
  }, [view]);

  function click() { audio.unlock(); audio.play('button'); }
  function navigate(next: View) {
    click(); setDialog(null); setOverOpen(false); setView(next);
    if (next === 'shop' && ads.supported) void ads.prepareReward().then(setRewardReady);
    if (next !== 'play') void ads.menuBanner();
  }
  function startGame(mode: Mode) {
    click(); animating.current = false;
    const next = newGame(mode, profileRef.current.best, utcDay());
    gameRef.current = next; setGame(next); setOverOpen(false); setDialog(null); setView('play');
    setBoardOverlay(null); setClearing([]); setPlaced([]); setBurst(null); setComboFeedback(null);
    setSelected(null); setHover(null); setReturning(null); dragRef.current = null; setDrag(null);
    commit(p => ({ ...p, lastSession: next, stats: { ...p.stats, games: p.stats.games + 1 } }));
    void ads.hideBanner();
  }
  function resumeGame(session: Game) {
    click(); gameRef.current = session; setGame(session); setView('play'); setDialog(null); setOverOpen(false);
    setBoardOverlay(null); setClearing([]); animating.current = false;
  }
  function playEndless() {
    const saved = profileRef.current.lastSession;
    if (saved && !saved.over && saved.mode === 'endless') resumeGame(saved);
    else requestNewGame('endless');
  }
  function playDaily() {
    const saved = profileRef.current.lastSession;
    if (saved && !saved.over && saved.mode === 'daily' && saved.dailyDate === utcDay()) resumeGame(saved);
    else requestNewGame('daily');
  }
  function requestNewGame(mode: Mode) {
    const saved = profileRef.current.lastSession;
    if (saved && !saved.over && saved.moves > 0) { click(); pendingMode.current = mode; setDialog('restart'); }
    else startGame(mode);
  }
  function finishGame(current: Game, userInitiated = true) {
    if (gameRef.current.id !== current.id) return;
    let finished = current;
    if (!current.settled) {
      const record = current.score > current.bestAtStart;
      finished = { ...current, settled: true, coinsEarned: current.coinsEarned + (record ? 30 : 0), xpEarned: current.xpEarned + (record ? 60 : 0) };
      gameRef.current = finished; setGame(finished);
      commit(p => ({ ...p, lastSession: finished, coins: p.coins + (record ? 30 : 0), xp: p.xp + (record ? 60 : 0), stats: { ...p.stats, records: p.stats.records + (record ? 1 : 0) } }));
      if (userInitiated) { ads.gameFinished(); audio.play(record ? 'record' : 'over'); }
    } else if (userInitiated) audio.play('over');
    if (userInitiated && navigation.current.view === 'play') setOverOpen(true);
    if (userInitiated && !finished.revived && ads.supported) void ads.prepareReward().then(setRewardReady);
  }
  useEffect(() => {
    const savedGame = profileRef.current.lastSession;
    // Recover exactly once if the app closed between the final move and celebration.
    // Never initialize or display an advertisement during launch.
    if (savedGame?.over && !savedGame.settled) finishGame(savedGame, false);
  }, []);
  useEffect(() => {
    if (!dialog && !overOpen) return;
    cancelAnimationFrame(frame.current); frame.current = 0;
    dragRef.current = null; setDrag(null); setSelected(null); setHover(null);
  }, [dialog, overOpen]);
  function move(index: number, row: number, col: number) {
    if (view !== 'play' || dialog || overOpen || animating.current || adBusy) return false;
    const result = placePiece(gameRef.current, index, row, col);
    if (!result) { audio.play('invalid'); notify('Not quite enough space', 'Try another spot. Your block is still in the tray.'); return false; }
    gameRef.current = result.game; setGame(result.game); setSelected(null); setHover(null); setPlaced(result.placed);
    const previousDaily = profileRef.current.daily[result.game.dailyDate]?.completed;
    const next = commit(p => advanceDaily({
      ...p, lastSession: result.game, best: Math.max(p.best, result.game.score), coins: p.coins + result.coins, xp: p.xp + result.xp,
      stats: { ...p.stats, blocks: p.stats.blocks + result.placed.length, lines: p.stats.lines + result.lineCount,
        clearMoves: p.stats.clearMoves + (result.lineCount ? 1 : 0), maxCombo: Math.max(p.stats.maxCombo, result.game.combo),
        maxClear: Math.max(p.stats.maxClear, result.lineCount), totalScore: p.stats.totalScore + result.points,
        perfectClears: p.stats.perfectClears + (result.lineCount && result.game.board.every(c => c === null) ? 1 : 0) },
    }, result.game));
    if (result.game.mode === 'daily' && !previousDaily && next.daily[result.game.dailyDate]?.completed) {
      notify('Daily challenge complete!', 'Your 150 coins and 250 XP are ready to collect.'); audio.play('reward');
    }
    haptic(profileRef.current.settings.haptics, result.lineCount > 1);
    if (result.lineCount) {
      animating.current = true; setBoardOverlay(result.beforeClear); setClearing(result.cleared);
      const text = result.lineCount >= 4 ? 'MEGA CLEAR!' : result.lineCount === 3 ? 'TRIPLE CLEAR!' : result.lineCount === 2 ? 'DOUBLE CLEAR!' : result.game.combo >= 4 ? 'COMBO!' : result.game.combo === 3 ? 'GREAT!' : result.game.combo === 2 ? 'NICE!' : 'GOOD!';
      setComboFeedback({ text, points: result.points, combo: result.game.combo, id: result.game.moves });
      if (result.lineCount >= 3) setShake(true);
      audio.play(result.lineCount >= 3 ? 'mega' : result.game.combo > 1 ? 'combo' : 'clear');
      later(() => {
        if (gameRef.current.id !== result.game.id) return;
        setBoardOverlay(null); setClearing([]); animating.current = false;
        setBurst({ cells: result.cleared, board: result.beforeClear, id: result.game.moves });
      }, profile.settings.reducedMotion ? 60 : 220);
      later(() => { if (gameRef.current.id === result.game.id) { setBurst(null); setShake(false); } }, 850);
      later(() => { if (gameRef.current.id === result.game.id) setComboFeedback(current => current?.id === result.game.moves ? null : current); }, 1150);
    } else audio.play('place');
    later(() => { if (gameRef.current.id === result.game.id && gameRef.current.moves === result.game.moves) setPlaced([]); }, 280);
    if (result.game.over) later(() => finishGame(result.game), result.lineCount ? 850 : 400);
    return true;
  }

  function metrics() {
    if (!boardRef.current) return null;
    const rect = boardRef.current.getBoundingClientRect();
    const gap = parseFloat(getComputedStyle(boardRef.current).columnGap) || 5;
    const cell = (rect.width - gap * 7) / 8;
    return { rect, gap, unit: cell + gap };
  }
  function calculateDrag(current: Drag, x: number, y: number): Drag {
    const m = metrics(); if (!m) return current;
    const left = x - current.offsetX, top = y - current.offsetY - current.lift;
    const col = Math.round((left - m.rect.left) / m.unit), row = Math.round((top - m.rect.top) / m.unit);
    const d = dimensions(current.piece);
    const overBoard = left < m.rect.right && left + d.width * m.unit > m.rect.left && top < m.rect.bottom && top + d.height * m.unit > m.rect.top;
    return { ...current, x, y, left, top, row, col, unit: m.unit, gap: m.gap, overBoard,
      valid: overBoard && canPlace(gameRef.current.board, current.piece, row, col),
      moved: current.moved || Math.hypot(x - current.startX, y - current.startY) > 6 };
  }
  function pickUp(event: ReactPointerEvent<HTMLButtonElement>, index: number) {
    if (event.button !== 0 || dialog || overOpen || adBusy) return;
    if (view === 'home') { playEndless(); return; }
    if (view !== 'play' || animating.current || returning) return;
    const piece = gameRef.current.pieces[index], m = metrics();
    const original = event.currentTarget.querySelector<HTMLElement>('.piece-shape')?.getBoundingClientRect();
    if (!piece || !m || !original) return;
    event.preventDefault(); audio.unlock(); setSelected(null); setHover(null);
    event.currentTarget.setPointerCapture(event.pointerId);
    const d = dimensions(piece);
    const offsetX = Math.max(0, Math.min(1, (event.clientX - original.left) / original.width)) * (d.width * m.unit - m.gap);
    const offsetY = Math.max(0, Math.min(1, (event.clientY - original.top) / original.height)) * (d.height * m.unit - m.gap);
    const initial: Drag = { index, piece, pointerId: event.pointerId, x: event.clientX, y: event.clientY,
      left: event.clientX - offsetX, top: event.clientY - offsetY, offsetX, offsetY,
      lift: event.pointerType === 'touch' ? 64 : 0, unit: m.unit, gap: m.gap, row: -10, col: -10,
      valid: false, overBoard: false, moved: false, startX: event.clientX, startY: event.clientY,
      originLeft: original.left, originTop: original.top, originUnit: (original.width + 4) / d.width };
    const next = calculateDrag(initial, event.clientX, event.clientY);
    dragRef.current = next; setDrag(next);
  }
  function dragMove(event: ReactPointerEvent<HTMLButtonElement>) {
    const current = dragRef.current;
    if (!current || current.pointerId !== event.pointerId) return;
    // Keep the latest pointer coordinates; read layout and render only once per frame.
    dragRef.current = { ...current, x: event.clientX, y: event.clientY,
      moved: current.moved || Math.hypot(event.clientX - current.startX, event.clientY - current.startY) > 6 };
    if (!frame.current) frame.current = requestAnimationFrame(() => {
      frame.current = 0;
      const latest = dragRef.current;
      if (latest) { const next = calculateDrag(latest, latest.x, latest.y); dragRef.current = next; setDrag(next); }
    });
  }
  function returnToTray(current: Drag) {
    setReturning({ piece: current.piece, left: current.left, top: current.top, dx: current.originLeft - current.left,
      dy: current.originTop - current.top, unit: current.unit, gap: current.gap, scale: current.originUnit / current.unit });
    later(() => setReturning(null), 210);
  }
  function release(event: ReactPointerEvent<HTMLButtonElement>, cancelled = false) {
    if (!dragRef.current || dragRef.current.pointerId !== event.pointerId) return;
    const current = calculateDrag(dragRef.current, event.clientX, event.clientY);
    cancelAnimationFrame(frame.current); frame.current = 0; dragRef.current = null; setDrag(null);
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    if (cancelled) { returnToTray(current); return; }
    if (!current.moved) {
      setSelected(current.index); setCursor(0); setHover(null);
      if (!profileRef.current.seenTutorial) {
        notify('Drag it, or tap to place it', 'Select a block, then tap the board. Arrow keys and Enter work too.');
        commit(p => ({ ...p, seenTutorial: true }), false);
      }
      return;
    }
    if (current.valid && current.overBoard && move(current.index, current.row, current.col)) return;
    returnToTray(current);
    if (current.overBoard) { audio.play('invalid'); notify('This spot is a little crowded', 'Find an empty space for every square in your block.'); }
  }
  function cellClick(row: number, col: number) {
    if (selected !== null) move(selected, row, col);
    else if (view === 'play' && !drag) notify('Choose your next block', 'Drag a piece from the tray, or tap one to select it.');
  }
  function boardKey(index: number, event: ReactKeyboardEvent<HTMLButtonElement>) {
    let next = index;
    if (event.key === 'ArrowLeft') next = index % 8 ? index - 1 : index;
    else if (event.key === 'ArrowRight') next = index % 8 < 7 ? index + 1 : index;
    else if (event.key === 'ArrowUp') next = index >= 8 ? index - 8 : index;
    else if (event.key === 'ArrowDown') next = index < 56 ? index + 8 : index;
    else if (event.key === 'Escape') { setSelected(null); setHover(null); return; }
    else return;
    event.preventDefault(); setCursor(next); setHover({ row: Math.floor(next / 8), col: next % 8 });
    boardRef.current?.querySelectorAll<HTMLButtonElement>('button')[next]?.focus();
  }
  function buy(cosmetic: Cosmetic) {
    click(); const next = purchaseCosmetic(profileRef.current, cosmetic);
    if (!next) { notify('A few more coins, a little more color', `Earn ${number(cosmetic.price - profileRef.current.coins)} more coins by playing or claiming achievements.`); return; }
    const wasOwned = profileRef.current.unlocked.includes(`${cosmetic.category}:${cosmetic.id}`);
    commit(() => next); audio.play('reward');
    notify(wasOwned ? `${cosmetic.name} equipped` : `${cosmetic.name} is yours!`, 'All style. No gameplay advantages.');
  }
  function claimDaily() {
    click(); const next = claimDailyReward(profileRef.current);
    if (!next) return;
    commit(() => next); audio.play('reward'); haptic(profile.settings.haptics);
    notify('A mission well played', '+150 coins · +250 XP. See you in your next orbit.');
  }
  function claimAward(achievement: Achievement) {
    click(); const next = claimAchievement(profileRef.current, achievement);
    if (!next) return;
    commit(() => next); audio.play('reward'); notify(`${achievement.name} — collected!`, `+${achievement.coins} coins${achievement.cosmetic ? ' and Rainbow blocks unlocked' : ''}.`);
  }
  function toggleSetting(key: keyof Settings) {
    click(); commit(p => ({ ...p, settings: { ...p.settings, [key]: !p.settings[key] } }), false);
  }
  async function revive() {
    if (adBusy || !ads.rewardAvailable || gameRef.current.revived) return;
    click(); setAdBusy(true); setRewardReady(false); audio.suspend(true);
    const earned = await ads.showReward(); audio.suspend(false);
    if (earned) {
      const next = reviveGame(gameRef.current);
      if (next) {
        gameRef.current = next; setGame(next); setOverOpen(false); setDialog(null);
        commit(p => ({ ...p, lastSession: next, stats: { ...p.stats, revives: p.stats.revives + 1 } }));
        notify('A little breathing room', 'One fair second chance. Make it a good one.'); audio.play('reward');
      }
    } else notify('No ad available right now', 'No worries. Your progress and earned rewards are safe.');
    setAdBusy(false);
  }
  async function bonusCoins() {
    const p = profileRef.current;
    if (adBusy || !ads.rewardAvailable || p.adBonus.date === utcDay() && p.adBonus.count >= 3) return;
    click(); setAdBusy(true); setRewardReady(false); audio.suspend(true);
    const earned = await ads.showReward(); audio.suspend(false);
    if (earned) {
      commit(current => ({ ...current, coins: current.coins + 75, adBonus: { date: utcDay(), count: current.adBonus.date === utcDay() ? current.adBonus.count + 1 : 1 } }));
      notify('A little extra stardust', '+75 coins. Thanks for supporting your orbit.'); audio.play('reward');
    } else notify('No ad available right now', 'You can always earn coins by playing.');
    setAdBusy(false);
  }
  async function afterGame(action: 'again' | 'home') {
    if (adBusy) return;
    click(); setAdBusy(true); audio.suspend(true);
    await ads.naturalBreak(); audio.suspend(false); setAdBusy(false);
    if (action === 'again') startGame(gameRef.current.mode);
    else { setOverOpen(false); setView('home'); }
  }

  const level = levelInfo(profile.xp);
  const mission = dailyMission(today);
  const daily = profile.daily[today] ?? { progress: 0, completed: false, claimed: false };
  const available = rewardReady && online && ads.rewardAvailable;
  const nextUnlock = COSMETICS.filter(c => c.level && c.level > level.level).sort((a, b) => (a.level ?? 0) - (b.level ?? 0))[0];
  const nextMilestone = ACHIEVEMENTS.find(a => a.value(profile) < a.target) ?? ACHIEVEMENTS[13];
  const readyAwards = ACHIEVEMENTS.filter(a => a.value(profile) >= a.target && !profile.claimedAchievements.includes(a.id)).length;
  const completedAwards = ACHIEVEMENTS.filter(a => a.value(profile) >= a.target).length;
  const shownAchievements = ACHIEVEMENTS.filter(a => achievementFilter === 'all' || (achievementFilter === 'ready' ? a.value(profile) >= a.target && !profile.claimedAchievements.includes(a.id) : profile.claimedAchievements.includes(a.id)));
  const saved = profile.lastSession;
  const canResume = saved && !saved.over && saved.mode === 'endless';
  const skin = profile.selected.skin;
  const pieces = view === 'home' ? MENU_PIECES : game.pieces;
  const preview: PlacementPreview | null = useMemo(() => {
    if (drag?.overBoard) return { piece: drag.piece, row: drag.row, col: drag.col, valid: drag.valid };
    const piece = selected !== null ? game.pieces[selected] : null;
    return piece && hover ? { piece, ...hover, valid: canPlace(game.board, piece, hover.row, hover.col) } : null;
  }, [drag, selected, game.pieces, game.board, hover]);
  const remainingMs = Math.max(0, Date.parse(`${today}T00:00:00Z`) + 86_400_000 - clock);
  const resetTime = `${Math.floor(remainingMs / 3_600_000)}h ${Math.floor(remainingMs % 3_600_000 / 60_000)}m`;
  const gameRecord = game.score > game.bestAtStart;

  function closeDialog() {
    click(); setDialog(dialog === 'privacy' || dialog === 'terms' ? 'settings' : null);
  }
  const DailyCard = () => <section className="daily-card">
    <img className="daily-card-art" src="/images/cosmic-challenge.jpg" alt="An original violet planet surrounded by stardust" />
    <div className="daily-card-inner"><div className="card-eyebrow"><CalendarDays size={14} /> DAILY CHALLENGE <span className="new-dot" /></div>
      <div className="daily-card-spacer" /><h3>{mission.title}</h3><p>{mission.description}</p>
      <div className="reward-chips"><span><Coins size={14} />150 coins</span><span><Sparkles size={13} />250 XP</span></div>
      <div className="daily-progress"><span>{daily.claimed ? 'Mission accomplished' : daily.completed ? 'Your reward is ready!' : 'Your progress'}<b>{number(Math.min(daily.progress, mission.target))}<em> / {number(mission.target)}</em></b></span><div className="progress-track"><i style={{ width: `${Math.min(100, daily.progress / mission.target * 100)}%` }} /></div></div>
      <button className="daily-card-button" onClick={() => daily.completed && !daily.claimed ? claimDaily() : navigate('daily')}>{daily.completed && !daily.claimed ? 'Collect your reward' : daily.claimed ? 'Challenge completed' : 'Take the challenge'}<ArrowUpRight size={17} /></button>
    </div>
  </section>;

  return <div className={`app theme-${profile.selected.theme} skin-${skin} ${profile.settings.reducedMotion ? 'reduce-motion' : ''}`}>
    <div className="ambient-stars" aria-hidden="true">{Array.from({ length: 24 }, (_, i) => <i key={i} style={{ left: `${(i * 43 + 11) % 100}%`, top: `${(i * 29 + 7) % 96}%`, opacity: .14 + (i % 3) * .06, width: i % 4 ? 2 : 3, height: i % 4 ? 2 : 3 }} />)}</div>
    <header className="site-header"><div className="header-inner">
      <button className="brand" onClick={() => navigate('home')} aria-label="Block Blast Puzzle home"><BrandMark /><span><strong>BLOCK BLAST <b>PUZZLE</b></strong><small>BLAST <i>•</i> MATCH <i>•</i> CLEAR <i>•</i> SCORE</small></span></button>
      <nav className="main-nav" aria-label="Main navigation">{navItems.map(item => { const Icon = item.icon; const active = item.view === 'home' ? view === 'home' || view === 'play' : view === item.view; return <button key={item.view} className={`nav-item ${active ? 'active' : ''}`} onClick={() => navigate(item.view)} aria-current={active ? 'page' : undefined}><Icon size={17} /><span>{item.label}</span>{item.view === 'achievements' && readyAwards > 0 && <i className="nav-badge">{readyAwards}</i>}</button>; })}</nav>
      <div className="header-actions"><button className="coin-wallet" onClick={() => navigate('shop')} aria-label={`${number(profile.coins)} coins. Open cosmetic shop`}><Coins size={18} /><strong>{number(profile.coins)}</strong><span>coins</span></button><div className="level-avatar" title={`Player level ${level.level}`} aria-label={`Player level ${level.level}`}>{level.level}<span>LVL</span></div><button className="icon-button settings-button" onClick={() => { click(); setDialog('settings'); }} aria-label="Open settings"><SettingsIcon size={20} /></button></div>
    </div></header>

    <main className={`main-content view-${view}`}>
      {(view === 'home' || view === 'play') && <div className="dashboard-grid">
        <aside className="left-column">
          <div className="intro-copy"><div className="eyebrow mint"><i className="status-dot" />{view === 'home' ? 'A LITTLE DAILY ESCAPE' : 'WELCOME TO YOUR ORBIT'}</div>
            <h1>{view === 'home' ? <>Small blocks.<br /><span>Big possibilities.</span></> : <>One good move.<br /><span>Then another.</span></>}</h1>
            <p>{view === 'home' ? <>Clear your mind. Clear the board.<br />Find your flow among the stars.</> : <>Take your time. The stars aren’t<br />going anywhere.</>}</p>
            <button className={`button ${view === 'home' ? 'button-primary' : 'button-outline'} intro-play`} onClick={() => view === 'home' ? playEndless() : requestNewGame(game.mode)}>{view === 'home' ? <Play size={17} fill="currentColor" /> : <RotateCcw size={16} />}{view === 'home' ? canResume ? 'Continue playing' : 'Play now' : 'New game'}<ArrowRight size={17} className="button-end" /></button>
            <div className="intro-meta"><InfinityIcon size={15} />Endless play. Zero pressure.</div>
            {view === 'home' && !phoneInstall.installed && !Capacitor.isNativePlatform() && <button className="home-phone-install" onClick={() => { click(); setDialog('install'); }}><ArrowUpRight size={14} />Install on phone<span>FREE</span></button>}
          </div>
          <section className="player-card"><div className="player-card-top"><div className="orbit-avatar"><OrbitMark size={43} /></div><div><small>YOUR JOURNEY</small><h3>{level.title}</h3></div><span className="level-chip">LVL {level.level}</span></div><div className="xp-label"><span>Level {level.level}<b>Level {level.level + 1}</b></span><div className="progress-track"><i style={{ width: `${level.progress * 100}%` }} /></div><small>{number(level.current)} / {number(level.required)} XP</small></div><div className="next-unlock"><Lock size={12} /><span>{nextUnlock ? <>Next unlock: <strong>{nextUnlock.name}{nextUnlock.category === 'skin' ? ' blocks' : ''}</strong></> : 'Your universe is wide open.'}</span></div></section>
          <button className="customize-card" onClick={() => navigate('shop')}><span className="customize-icon"><Sparkles size={19} /></span><span><strong>Make it yours.</strong><small>A little color. A little you.</small></span><ChevronRight size={17} /></button>
          <div className="quick-settings"><button className={profile.settings.sound ? 'enabled' : ''} onClick={() => toggleSetting('sound')} aria-label={`Sound ${profile.settings.sound ? 'on' : 'off'}. Toggle sound`} title="Toggle sound">{profile.settings.sound ? <Volume2 size={17} /> : <VolumeX size={17} />}</button><button className={profile.settings.music ? 'enabled' : ''} onClick={() => toggleSetting('music')} aria-label={`Music ${profile.settings.music ? 'on' : 'off'}. Toggle music`} title="Toggle music"><Music2 size={17} /></button><button className={profile.settings.haptics ? 'enabled' : ''} onClick={() => toggleSetting('haptics')} aria-label={`Haptics ${profile.settings.haptics ? 'on' : 'off'}. Toggle haptics`} title="Toggle haptics"><Vibrate size={17} /></button><span>Your space. Your rules.</span></div>
        </aside>

        <section className="game-column" aria-label={view === 'home' ? 'Play Block Blast Puzzle' : 'Active block puzzle game'}>
          <div className="mode-bar"><span><Gamepad2 size={16} />{view === 'play' && game.mode === 'daily' ? 'DAILY CHALLENGE' : 'ENDLESS MODE'}</span><small><InfinityIcon size={16} />{view === 'play' && game.mode === 'daily' ? `${number(Math.min(game[mission.metric], mission.target))} / ${number(mission.target)}` : 'NO TIME LIMIT'}</small></div>
          <div className="score-bar"><div className="score-stat"><span>SCORE</span><strong aria-live="polite">{number(view === 'home' ? canResume ? saved.score : 0 : game.score)}</strong></div><div className="score-stat best-stat"><span><Trophy size={13} />BEST SCORE</span><strong>{number(profile.best)}</strong></div><div className="score-stat combo-stat"><span><Flame size={13} />COMBO</span><strong>{view === 'play' ? Math.max(1, game.combo) : 1}<em>×</em></strong></div></div>
          <div className={`board-shell ${shake ? 'board-shake' : ''} ${view === 'home' ? 'menu-board-shell' : ''}`}>
            <Board board={view === 'home' ? MENU_BOARD : boardOverlay ?? game.board} skin={skin} boardRef={boardRef} preview={view === 'play' ? preview : null} clearing={clearing} placed={placed} cursor={cursor} onCell={cellClick} onHover={(row, col) => { if (!dragRef.current) setHover({ row, col }); }} onLeave={() => { if (!dragRef.current) setHover(null); }} onKey={boardKey} decorative={view === 'home'} />
            {view === 'home' && <div className="home-board-overlay"><div className="home-board-caption"><div className="little-stars"><Sparkles size={23} /></div><h2>Find your flow.</h2><p>A fresh board. Endless possibilities.</p><button className="button button-primary board-play" onClick={playEndless}><Play size={16} fill="currentColor" />{canResume ? 'Continue your orbit' : 'Let’s play'}<ArrowRight size={16} /></button><span>8 × 8 blocks. One beautiful brain break.</span></div></div>}
            {burst && view === 'play' && <ParticleBurst key={burst.id} cells={burst.cells} board={burst.board} skin={skin} effect={profile.selected.effect} />}
            {comboFeedback && view === 'play' && <div className={`combo-feedback combo-size-${Math.min(4, comboFeedback.combo)}`} key={comboFeedback.id} aria-live="polite"><Sparkles size={25} /><strong>{comboFeedback.text}</strong><span>+{number(comboFeedback.points)}{comboFeedback.combo > 1 ? ` · ${comboFeedback.combo}× STREAK` : ' · BEAUTIFULLY DONE'}</span></div>}
            {view === 'play' && preview && !preview.valid && <div className="invalid-placement"><X size={12} />Needs more space</div>}
          </div>
          <div className="piece-tray"><div className="tray-label">{view === 'home' ? 'THREE BLOCKS. SO MANY POSSIBILITIES.' : selected !== null ? 'TAP AN EMPTY SPACE TO PLACE YOUR BLOCK' : 'MAKE YOUR NEXT MOVE'}</div><div className="piece-slots">{pieces.map((piece, index) => <button type="button" key={index} className={`piece-slot ${selected === index ? 'piece-selected' : ''} ${piece && view === 'play' && !hasLegalPlacement(game.board, piece) ? 'piece-unavailable' : ''} ${piece && (drag?.piece.id === piece.id || returning?.piece.id === piece.id) ? 'piece-picked-up' : ''}`} disabled={!piece || view === 'play' && (animating.current || overOpen || !!dialog || adBusy)} aria-label={piece ? `${piece.name}, ${piece.cells.length} squares. Drag onto the board or select to place.` : 'Piece placed'} aria-pressed={selected === index} onPointerDown={e => pickUp(e, index)} onPointerMove={dragMove} onPointerUp={e => release(e)} onPointerCancel={e => release(e, true)} onClick={e => { if (e.detail === 0 && piece) { if (view === 'home') playEndless(); else { click(); setSelected(index); setHover({ row: 0, col: 0 }); setCursor(0); boardRef.current?.querySelector<HTMLButtonElement>('button')?.focus(); } } }}>
            {piece ? <div className="tray-piece-scale"><PieceShape piece={piece} unit={Math.max(9, Math.min(25, (boardWidth / 3 - 10) / dimensions(piece).width, (window.innerWidth <= 600 && window.innerHeight <= 740 && window.innerHeight >= window.innerWidth ? 52 : 70) / dimensions(piece).height))} gap={4} skin={skin} /></div> : <span className="empty-piece"><Check size={19} /></span>}
          </button>)}</div></div>
          <div className="game-controls"><button onClick={() => { click(); setDialog('help'); }}><HelpCircle size={14} />How to play</button>{view === 'play' ? <div><button onClick={() => { click(); setDialog('pause'); }} aria-label="Pause game"><Pause size={14} />Pause</button><button onClick={() => requestNewGame(game.mode)} aria-label="Restart game"><RotateCcw size={14} />Restart</button></div> : <span><Hand size={14} />Drag, drop, find your flow.</span>}</div>
          {view === 'play' && game.mode === 'daily' && daily.completed && !daily.claimed && <button className="daily-complete-inline" onClick={claimDaily}><Gift size={16} />Mission complete! Collect 150 coins + 250 XP<ArrowRight size={16} /></button>}
        </section>

        <aside className="right-column">{DailyCard()}<section className="how-to-card"><div className="card-heading"><h3>A little how-to</h3><span><HelpCircle size={15} /></span></div><div className="how-to-step"><span className="step-number step-purple">1</span><div><strong>Find a home.</strong><p>Drag blocks into empty spaces.</p></div></div><div className="how-to-step"><span className="step-number step-mint">2</span><div><strong>Make some space.</strong><p>Fill a row or column to clear it.</p></div></div><div className="how-to-step"><span className="step-number step-peach">3</span><div><strong>Keep the good going.</strong><p>Chain clears for bigger combos.</p></div></div><div className="how-to-footer"><Heart size={12} />No rush. You’ve got this.</div></section><button className="milestone-card" onClick={() => navigate('achievements')}><span className="milestone-icon"><Award size={22} /></span><span><small>NEXT MILESTONE</small><strong>{nextMilestone.name}</strong><em>{nextMilestone.description}</em></span><ChevronRight size={16} /></button></aside>
      </div>}

      {view === 'shop' && <section className="page-section shop-page"><div className="page-heading"><div><div className="eyebrow mint"><Sparkles size={14} /> A UNIVERSE OF YOUR OWN</div><h1>Make it yours.</h1><p>Different colors. Same possibilities. Find your kind of cosmic.</p></div><div className="shop-balance"><Coins size={25} /><div><strong>{number(profile.coins)}</strong><span>coins in your orbit</span></div></div></div>
        <div className="page-toolbar"><div className="tabs">{([{ id: 'skin', label: 'Block skins', icon: Grid2X2 }, { id: 'theme', label: 'Board themes', icon: Layers3 }, { id: 'effect', label: 'Clear effects', icon: Zap }] as const).map(tab => <button key={tab.id} className={shopCategory === tab.id ? 'active' : ''} onClick={() => { click(); setShopCategory(tab.id); }}><tab.icon size={16} />{tab.label}</button>)}</div><span className="cosmetic-note"><ShieldCheck size={15} />All style. Never pay-to-win.</span></div>
        <div className="cosmetics-grid">{COSMETICS.filter(c => c.category === shopCategory).map(cosmetic => {
          const owned = profile.unlocked.includes(`${cosmetic.category}:${cosmetic.id}`), equipped = profile.selected[cosmetic.category] === cosmetic.id;
          return <article className={`cosmetic-card ${equipped ? 'equipped' : ''}`} key={`${cosmetic.category}:${cosmetic.id}`}><div className={`cosmetic-preview ${cosmetic.category === 'theme' ? `theme-${cosmetic.id}` : ''}`}>
            {owned && <span className={`owned-badge ${equipped ? 'is-equipped' : ''}`}><Check size={12} />{equipped ? 'Equipped' : 'Owned'}</span>}
            {cosmetic.category === 'skin' && <SkinSwatch skin={cosmetic.id} />}
            {cosmetic.category === 'theme' && <div className="theme-board-preview"><Board board={MENU_BOARD} skin={skin} decorative /></div>}
            {cosmetic.category === 'effect' && <button className={`effect-demo effect-${cosmetic.id}`} onClick={() => { click(); setEffectPreview(null); requestAnimationFrame(() => setEffectPreview(cosmetic.id)); audio.play('clear'); later(() => setEffectPreview(null), 900); }} aria-label={`Preview ${cosmetic.name} effect`}><div className="effect-demo-orbit" /><Sparkles size={43} className="effect-demo-star" />{effectPreview === cosmetic.id && <ParticleBurst cells={[18, 19, 20, 27, 35, 36, 37, 44, 45]} board={MENU_BOARD} skin={skin} effect={cosmetic.id} />}<span>Tap to preview</span></button>}
          </div><div className="cosmetic-details"><h3>{cosmetic.name}</h3><p>{cosmetic.subtitle}</p><button className={`button ${equipped ? 'button-equipped' : owned ? 'button-outline' : 'button-shop'}`} disabled={equipped} onClick={() => buy(cosmetic)}>{equipped ? <><Check size={15} />Equipped</> : owned ? 'Equip' : <><Coins size={15} />{number(cosmetic.price)} coins<span>Unlock<ArrowRight size={14} /></span></>}</button><small>{cosmetic.level ? `Or unlock free at player level ${cosmetic.level}` : cosmetic.price ? 'Yours to keep. Yours to play.' : 'A little gift from our universe.'}</small></div></article>;
        })}</div><div className="shop-bottom-note"><Gift size={18} /><p>{profile.stats.blocks === 0 ? 'Your first 250 coins are on us. ' : ''}Earn more by clearing lines, completing missions, and claiming achievements.</p>{available && !(profile.adBonus.date === today && profile.adBonus.count >= 3) && <button className="button button-outline" disabled={adBusy} onClick={bonusCoins}><Play size={14} />Optional ad · +75 coins</button>}</div>
      </section>}

      {view === 'achievements' && <section className="page-section achievements-page"><div className="page-heading"><div><div className="eyebrow mint"><Award size={15} /> LITTLE WINS. BRIGHTER ORBITS.</div><h1>Your constellation.</h1><p>Every block is a step forward. Every milestone deserves a little celebration.</p></div><div className="achievement-overview"><div className="achievement-orbit"><Trophy size={27} /></div><div><strong>{completedAwards}<em> / {ACHIEVEMENTS.length}</em></strong><span>achievements unlocked</span></div></div></div><div className="page-toolbar"><div className="tabs"><button className={achievementFilter === 'all' ? 'active' : ''} onClick={() => { click(); setAchievementFilter('all'); }}>All achievements</button><button className={achievementFilter === 'ready' ? 'active' : ''} onClick={() => { click(); setAchievementFilter('ready'); }}>Ready to collect{readyAwards > 0 && <span className="tab-count">{readyAwards}</span>}</button><button className={achievementFilter === 'claimed' ? 'active' : ''} onClick={() => { click(); setAchievementFilter('claimed'); }}>Collected</button></div><span className="cosmetic-note"><Coins size={15} />A little reward for every win.</span></div>
        <div className="achievement-grid">{shownAchievements.map(a => {
          const value = Math.min(a.target, a.value(profile)), complete = value >= a.target, claimed = profile.claimedAchievements.includes(a.id), Icon = achievementIcons[a.icon];
          return <article className={`achievement-card ${complete ? 'achievement-unlocked' : ''} ${claimed ? 'achievement-claimed' : ''}`} key={a.id}><div className="achievement-card-top"><div className="achievement-icon"><Icon size={24} /></div><span className="achievement-reward"><Coins size={13} />{a.coins}</span></div><h3>{a.name}</h3><p>{a.description}</p><div className="progress-track"><i style={{ width: `${value / a.target * 100}%` }} /></div><div className="achievement-card-bottom"><span>{number(value)} <em>/ {number(a.target)}</em></span>{claimed ? <small><Check size={13} />Collected</small> : complete ? <button onClick={() => claimAward(a)}>Collect reward<ArrowRight size={13} /></button> : <Lock size={14} />}</div>{a.cosmetic && <div className="achievement-extra"><Sparkles size={12} />Also unlocks Rainbow blocks</div>}</article>;
        })}</div>{shownAchievements.length === 0 && <div className="empty-state"><OrbitMark size={80} /><h2>{achievementFilter === 'ready' ? 'Your next star is out there.' : 'A constellation in the making.'}</h2><p>{achievementFilter === 'ready' ? 'Place a few blocks and your first reward will be ready.' : 'Collect an unlocked achievement to start your collection.'}</p><button className="button button-primary" onClick={playEndless}><Play size={16} />Let’s play</button></div>}
      </section>}

      {view === 'daily' && <section className="page-section daily-page"><div className="page-heading"><div><div className="eyebrow mint"><CalendarDays size={15} /> A FRESH LITTLE CHALLENGE</div><h1>A new day. A new orbit.</h1><p>One mission a day. A little something to reach for.</p></div><span className="daily-date">{new Date(`${today}T12:00:00Z`).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</span></div><div className="daily-page-grid"><article className="daily-feature"><img src="/images/cosmic-challenge.jpg" alt="A glowing lavender planet in an original cosmic illustration" /><div className="daily-feature-content"><span className="challenge-number"><Star size={14} />TODAY’S MISSION</span><h2>{mission.title}</h2><p>{mission.description}</p><span className="daily-difficulty"><i /><i /><i className="dim" />A LITTLE STRATEGY. A LOT OF POSSIBILITY.</span></div></article><section className="daily-mission-panel"><div className="card-eyebrow"><Target size={15} />YOUR DAILY ORBIT</div><h3>{daily.claimed ? 'Beautifully done.' : daily.completed ? 'You reached the stars.' : 'Ready, star chaser?'}</h3><p>{daily.claimed ? 'Your reward is collected. Come back tomorrow for a new mission.' : daily.completed ? 'Your well-earned reward is ready.' : 'Complete the mission in a single run to earn your reward.'}</p><div className="mission-rewards"><div><Coins size={25} /><strong>150</strong><span>coins</span></div><div><Sparkles size={25} /><strong>250</strong><span>XP</span></div></div><div className="daily-progress"><span>Your best progress<b>{number(Math.min(daily.progress, mission.target))}<em> / {number(mission.target)}</em></b></span><div className="progress-track"><i style={{ width: `${Math.min(100, daily.progress / mission.target * 100)}%` }} /></div></div>{daily.completed && !daily.claimed && <button className="button button-primary" onClick={claimDaily}><Gift size={17} />Collect your reward<ArrowRight size={16} /></button>}<button className={`button ${daily.completed ? 'button-outline' : 'button-primary'}`} onClick={playDaily}><Play size={16} fill="currentColor" />{daily.completed ? 'Play again for the fun of it' : saved?.mode === 'daily' && saved.dailyDate === today && !saved.over ? 'Continue today’s challenge' : 'Play today’s challenge'}<ArrowRight size={16} /></button><div className="mission-reset"><RotateCcw size={13} />A fresh mission in {resetTime}<span>Resets at 00:00 UTC · One reward per day</span></div></section></div><div className="daily-notes"><section><div className="daily-note-icon"><ShieldCheck size={21} /></div><h3>Just you and the blocks.</h3><p>No timers, no energy meters, no entry fees. Take all the time you need.</p></section><section><div className="daily-note-icon mint-icon"><Layers3 size={21} /></div><h3>A fair starting orbit.</h3><p>The same seeded starting pieces for everyone, with fair, fitting new trays.</p></section><section><div className="daily-note-icon peach-icon"><Gift size={21} /></div><h3>A little extra stardust.</h3><p>Daily rewards are a bonus. Normal coins and XP are always yours to earn.</p></section></div></section>}
    </main>

    <footer className="site-footer"><div><WifiOff size={13} /><span>PLAY ANYWHERE. EVEN OFFLINE.</span></div><p>No timers. No pressure. Just one more block.</p><span>Made for your orbit.<i>✦</i></span></footer>
    <nav className="mobile-nav" aria-label="Mobile navigation">{navItems.map(item => { const Icon = item.icon; const active = item.view === 'home' ? view === 'home' || view === 'play' : view === item.view; return <button key={item.view} className={active ? 'active' : ''} onClick={() => navigate(item.view)} aria-current={active ? 'page' : undefined}><Icon size={19} /><span>{item.view === 'daily' ? 'Daily' : item.label}</span>{item.view === 'achievements' && readyAwards > 0 && <i />}</button>; })}</nav>

    {drag && <div className={`floating-piece ${drag.valid ? 'floating-valid' : drag.overBoard ? 'floating-invalid' : ''}`} style={{ transform: `translate3d(${drag.left}px, ${drag.top}px, 0)` }}><PieceShape piece={drag.piece} unit={drag.unit} gap={drag.gap} skin={skin} />{drag.overBoard && <span className="drag-status">{drag.valid ? <Check size={15} /> : <X size={15} />}</span>}</div>}
    {returning && <div className="returning-piece" style={{ left: returning.left, top: returning.top, '--return-x': `${returning.dx}px`, '--return-y': `${returning.dy}px`, '--return-scale': returning.scale } as CSSProperties}><PieceShape piece={returning.piece} unit={returning.unit} gap={returning.gap} skin={skin} /></div>}
    {toast && <div className="toast" key={toast.id} role="status"><span className="toast-icon"><Sparkles size={19} /></span><div><strong>{toast.title}</strong>{toast.description && <p>{toast.description}</p>}</div><button onClick={() => setToast(null)} aria-label="Dismiss notification"><X size={16} /></button></div>}

    {overOpen && <Dialog title={gameRecord ? 'A new personal best.' : 'Game over'} eyebrow={gameRecord ? 'NEW HIGH SCORE!' : 'ANOTHER ORBIT COMPLETE'} description={gameRecord ? 'Look how far your little blocks took you.' : 'Every orbit is a fresh beginning. Ready for another?'} onClose={() => { if (!adBusy) { setOverOpen(false); setView('home'); } }}>
      <div className={`game-over-art ${gameRecord ? 'is-record' : ''}`}><div /><Trophy size={47} />{gameRecord && <><i className="celebration-star star-a">✦</i><i className="celebration-star star-b">✦</i><i className="celebration-star star-c">✧</i></>}</div><div className="game-over-stats"><div><span>SCORE</span><strong>{number(game.score)}</strong></div><div><span>BEST</span><strong>{number(profile.best)}</strong></div><div><span><Coins size={12} />COINS EARNED</span><strong>+{number(game.coinsEarned)}</strong></div></div><div className="game-summary"><span>{game.lines} lines cleared</span><i>•</i><span>{game.maxCombo}× best streak</span><i>•</i><span>+{game.xpEarned} XP</span></div>
      {available && !game.revived && <button className="button button-revive" disabled={adBusy} onClick={revive}><Play size={16} />{adBusy ? 'One moment…' : 'Continue? Watch an optional ad'}<Heart size={16} /></button>}
      <button className="button button-primary full-width" disabled={adBusy} onClick={() => void afterGame('again')}><RotateCcw size={16} />{adBusy ? 'One moment…' : 'Play again'}<ArrowRight size={17} /></button><button className="button button-outline full-width" disabled={adBusy} onClick={() => void afterGame('home')}><Home size={16} />Home</button><p className="dialog-footnote">Your coins, XP, and best score are already saved.</p>
    </Dialog>}

    {dialog === 'install' && <PhoneInstall state={phoneInstall} onClose={closeDialog} notify={notify} />}
    {dialog === 'settings' && <Dialog title="Your space. Your rules." eyebrow="SETTINGS" description="Settle into your kind of flow." onClose={closeDialog}>
      {!Capacitor.isNativePlatform() && <button className="button button-outline full-width settings-phone-install" onClick={() => { click(); setDialog('install'); }}><ArrowUpRight size={16} />{phoneInstall.installed ? 'Installed game · phone information' : 'Install on phone'}<ChevronRight size={15} /></button>}
      <div className="settings-list"><Toggle label="Sound effects" description="Satisfying little sounds for every move." checked={profile.settings.sound} onChange={() => toggleSetting('sound')} /><Toggle label="Background music" description="An original, gentle cosmic melody." checked={profile.settings.music} onChange={() => toggleSetting('music')} /><Toggle label="Haptic feedback" description="A subtle tap when a block finds its home." checked={profile.settings.haptics} onChange={() => toggleSetting('haptics')} /><Toggle label="Reduced motion" description="Less motion. The same colorful play." checked={profile.settings.reducedMotion} onChange={() => toggleSetting('reducedMotion')} /></div><div className="settings-links"><button onClick={() => setDialog('privacy')}><ShieldCheck size={17} />Privacy policy<ChevronRight size={16} /></button><button onClick={() => setDialog('terms')}><Layers3 size={17} />Terms of service<ChevronRight size={16} /></button><button onClick={async () => { click(); const managed = await ads.privacyOptions(); notify(managed ? 'Your ad preferences are updated' : 'Personalized ads are off', managed ? 'Your choices are managed through Google’s consent form.' : 'Ad consent settings become available in the Android app when ads are available.'); }}><Target size={17} />Personalized ads<span>Manage<ChevronRight size={16} /></span></button></div><div className="settings-storage"><span><WifiOff size={14} />Progress saved on this device</span><button onClick={() => { click(); setDialog('reset'); }}>Reset progress</button></div><button className="diagnostics-link" onClick={() => { click(); const results = runCoreChecks(); const failures = results.filter(result => !result.passed); notify(failures.length ? 'A core check needs attention' : `${results.length} core checks passed`, failures.length ? failures[0].error : 'Placement, clears, combos, fair trays, revives, and reward transactions verified.'); }}><ShieldCheck size={13} />Check game integrity</button><p className="dialog-footnote">An original block puzzle. Cosmic edition · v1.0.0</p>
    </Dialog>}
    {dialog === 'help' && <Dialog title="A few blocks. A little strategy." eyebrow="HOW TO PLAY" description="Easy to learn. Plenty of room to get good." onClose={closeDialog}>
      <div className="help-steps"><div><span>1</span><section><h3>Give every block a home.</h3><p>Drag one of the three pieces into empty cells. Every square must fit. You can also tap a piece, then tap the board.</p></section></div><div><span>2</span><section><h3>A full line makes room for more.</h3><p>Complete a horizontal row or vertical column to clear it. Complete both together for a bigger bonus.</p></section></div><div><span>3</span><section><h3>Find your streak.</h3><p>Clear lines on consecutive moves to multiply your bonus. Place all three pieces to get a fresh tray.</p></section></div></div><div className="scoring-guide"><span>1 LINE<strong>+100</strong></span><span>2 LINES<strong>+250</strong></span><span>3 LINES<strong>+500</strong></span><span>4 LINES<strong>+1,000</strong></span></div><p className="help-tip"><Sparkles size={17} />Each placed square earns 10 points. Keep space for the larger pieces. The game ends only when no piece can fit.</p><p className="keyboard-note">Keyboard: Tab to select a piece · Arrow keys to move · Enter to place · Esc to deselect.</p><button className="button button-primary full-width" onClick={() => { setDialog(null); commit(p => ({ ...p, seenTutorial: true }), false); if (view === 'home') playEndless(); else click(); }}>Got it. Let’s find that flow.<ArrowRight size={17} /></button>
    </Dialog>}
    {dialog === 'pause' && <Dialog title="The stars can wait." eyebrow="GAME PAUSED" description="A little breather. Your orbit is right where you left it." onClose={closeDialog}><div className="pause-orbit"><OrbitMark size={94} /></div><div className="pause-score"><span>CURRENT SCORE</span><strong>{number(game.score)}</strong></div><button className="button button-primary full-width" onClick={closeDialog}><Play size={16} fill="currentColor" />Back to my orbit</button><button className="button button-outline full-width" onClick={() => navigate('home')}><Home size={16} />Save & go home</button><button className="text-button" onClick={() => requestNewGame(game.mode)}><RotateCcw size={14} />Start a fresh game</button></Dialog>}
    {dialog === 'restart' && <Dialog title="A fresh little beginning?" eyebrow="NEW GAME" description="Your current board will be replaced. Your earned coins, XP, and best score stay safely in your orbit." onClose={closeDialog}><div className="pause-orbit"><OrbitMark size={85} /></div><button className="button button-primary full-width" onClick={() => startGame(pendingMode.current)}><RotateCcw size={16} />Start fresh<ArrowRight size={16} /></button><button className="button button-outline full-width" onClick={closeDialog}>Keep my current game</button></Dialog>}
    {dialog === 'reset' && <Dialog title="Start your journey again?" eyebrow="RESET LOCAL PROGRESS" description="This permanently deletes your best score, coins, XP, cosmetics, achievements, challenges, and current game on this device." onClose={() => setDialog('settings')}><button className="button button-danger full-width" onClick={() => { let clearedStorage = true; try { localStorage.removeItem('orbit-block-puzzle-v1'); } catch { clearedStorage = false; } const fresh = defaultProfile(); profileRef.current = fresh; setProfile(fresh); const savedFresh = saveProfile(fresh); const next = newGame('endless'); gameRef.current = next; setGame(next); setOverOpen(false); setView('home'); setDialog(null); notify(clearedStorage && savedFresh ? 'A fresh orbit awaits' : 'This session was reset', clearedStorage && savedFresh ? 'Your local progress has been reset.' : 'This browser blocked saving. Old saved data may return after reopening.'); }}>Yes, reset all progress</button><button className="button button-outline full-width" onClick={() => setDialog('settings')}>Keep my progress</button></Dialog>}
    {(dialog === 'privacy' || dialog === 'terms') && <Dialog title={dialog === 'privacy' ? 'Privacy, in plain language.' : 'A fair little universe.'} eyebrow={dialog === 'privacy' ? 'PRIVACY POLICY' : 'TERMS OF SERVICE'} onClose={closeDialog} wide><div className="legal-copy">{dialog === 'privacy' ? <><p><strong>Effective date: July 2026.</strong> This original game stores your score, coins, XP, cosmetics, achievements, daily progress, settings, and current board locally on your device. We do not operate an account system, analytics service, or gameplay-data server.</p><h3>Optional advertising</h3><p>The browser version does not serve ads. The Android integration may use Google AdMob for optional rewarded ads and limited ads at natural breaks. When enabled, Google’s SDK may process advertising identifiers, IP addresses, device information, and ad interactions according to its privacy policy and your consent choices. Personalized requests are off by default. Ad preferences can be managed in Settings when the native service is available.</p><h3>Offline play & permissions</h3><p>No internet connection is needed for normal gameplay. Internet access is used only for optional ads and web updates. Native vibration is used only if haptics are enabled. The game does not request camera, microphone, location, contact, or storage-access permissions.</p><h3>Your choices</h3><p>Reset progress in Settings to remove local game data. Clearing this site’s browser data or uninstalling the app also removes its local save, subject to any device backup settings. No purchases, email addresses, or personal profiles are stored by this game.</p><p>This in-app notice describes the included implementation. The publishing operator must provide a public policy URL and contact details, and verify SDK disclosures before release.</p></> : <><p>This is an original casual block puzzle, with original visual design and synthesized audio. It is not affiliated with or endorsed by another puzzle-game publisher.</p><h3>Play & progression</h3><p>Normal play is free. In-game coins have no cash value, cannot be exchanged for money, and unlock only visual cosmetics. Daily and achievement rewards are claimable once per mission or achievement. Optional rewarded ads grant the stated reward only after the advertising provider confirms it.</p><h3>Local saves</h3><p>Progress belongs to this device or browser. There is no cloud recovery or cross-device account. Deleting app data or resetting progress is irreversible. Keep this in mind before uninstalling.</p><h3>Fair use</h3><p>Please do not redistribute game assets as your own, interfere with optional advertising, or misrepresent this game’s affiliation. Play responsibly and take breaks. Nothing in this notice limits your statutory consumer rights.</p><p>A production publisher must add its legal identity, contact details, and region-specific terms before a public release.</p></>}</div><button className="button button-outline full-width" onClick={() => setDialog('settings')}><ArrowLeft size={16} />Back to settings</button></Dialog>}
  </div>;
}
