import test from 'node:test';
import assert from 'node:assert/strict';
import { runCoreChecks } from '../src/game/checks';
import { newGame, placePiece } from '../src/game/engine';
import { SAVE_KEY, defaultProfile, loadProfile, saveProfile } from '../src/game/profile';
import { ads } from '../src/game/ads';

for (const result of runCoreChecks()) {
  test(result.name, () => assert.equal(result.passed, true, result.error));
}
function withStorage(fn: (data: Map<string, string>) => void) {
  const previous = Object.getOwnPropertyDescriptor(globalThis, 'localStorage');
  const data = new Map<string, string>();
  Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: {
    getItem: (key: string) => data.get(key) ?? null,
    setItem: (key: string, value: string) => data.set(key, value),
    removeItem: (key: string) => data.delete(key), clear: () => data.clear(),
    key: (index: number) => [...data.keys()][index] ?? null, get length() { return data.size; },
  } });
  try { fn(data); } finally { if (previous) Object.defineProperty(globalThis, 'localStorage', previous); else Reflect.deleteProperty(globalThis, 'localStorage'); }
}
test('Save/load restores full progression, settings, and current game', () => withStorage(() => {
  const p = defaultProfile(); const g = newGame('endless', 0, '2026-07-01', 81);
  p.lastSession = placePiece(g, 0, 0, 0)!.game; p.best = 9999; p.coins = 333; p.xp = 250;
  p.settings.music = true; p.claimedAchievements = ['first-flight']; p.stats.games = 2;
  assert.equal(saveProfile(p), true);
  const loaded = loadProfile(); assert.equal(loaded.best, 9999); assert.equal(loaded.coins, 333);
  assert.equal(loaded.xp, 250); assert.equal(loaded.settings.music, true);
  assert.deepEqual(loaded.lastSession, p.lastSession); assert.deepEqual(loaded.claimedAchievements, ['first-flight']);
  assert.ok(loaded.unlocked.includes('skin:ice'));
}));
test('Malformed saves safely fall back to a fresh profile', () => withStorage(data => {
  data.set(SAVE_KEY, 'not valid json'); assert.deepEqual(loadProfile(), defaultProfile());
}));
test('Corrupt current games are discarded without losing valid progression', () => withStorage(data => {
  data.set(SAVE_KEY, JSON.stringify({ ...defaultProfile(), best: 1234, lastSession: { board: [], pieces: [] } }));
  const p = loadProfile(); assert.equal(p.best, 1234); assert.equal(p.lastSession, null);
}));
test('Daily claimed status survives closing and reopening', () => withStorage(() => {
  const p = defaultProfile(); p.daily['2026-07-01'] = { progress: 20, completed: true, claimed: true };
  saveProfile(p); assert.deepEqual(loadProfile().daily['2026-07-01'], p.daily['2026-07-01']);
}));
test('Ads unavailable on the web never show simulated inventory or grant a reward', async () => {
  assert.equal(ads.supported, false); assert.equal(ads.rewardAvailable, false);
  assert.equal(await ads.prepareReward(), false); assert.equal(await ads.showReward(), false);
  await ads.naturalBreak();
});
