import test from 'node:test';
import assert from 'node:assert/strict';
import { androidRequirement, formatApkSize, parseApkInfo } from '../src/install/apk';

const metadata = {
  schemaVersion: 1,
  file: 'Blast-Blocks.apk',
  packageId: 'games.orbit.blastblocks',
  version: '1.0',
  versionCode: 1,
  bytes: 5 * 1024 * 1024,
  sha256: 'a'.repeat(64),
  minSdk: 24,
  targetSdk: 36,
  signing: 'debug',
  signatureVerified: true,
  builtAt: '2026-07-01T12:00:00.000Z',
};

test('APK download metadata accepts a verified Android test build', () => {
  assert.deepEqual(parseApkInfo(metadata), metadata);
});
test('APK downloads never accept arbitrary URLs or path traversal', () => {
  for (const file of ['../../something.apk', 'https://example.com/game.apk', 'javascript:alert(1)', 'index.html']) {
    assert.equal(parseApkInfo({ ...metadata, file }), null);
  }
});
test('An APK must be signature-verified and have a valid checksum', () => {
  assert.equal(parseApkInfo({ ...metadata, signatureVerified: false }), null);
  assert.equal(parseApkInfo({ ...metadata, sha256: 'not-a-checksum' }), null);
  assert.equal(parseApkInfo({ ...metadata, signing: 'unsigned' }), null);
});
test('Missing APK files and malformed metadata do not create a download', () => {
  for (const value of [null, undefined, '<html>preview</html>', {}, { file: 'Blast-Blocks.apk' }]) assert.equal(parseApkInfo(value), null);
  assert.equal(parseApkInfo({ ...metadata, bytes: 0 }), null);
  assert.equal(parseApkInfo({ ...metadata, bytes: NaN }), null);
  assert.equal(parseApkInfo({ ...metadata, builtAt: 'unknown' }), null);
  assert.equal(parseApkInfo({ ...metadata, packageId: 'invalid package' }), null);
});
test('APK version and minimum Android information must be valid', () => {
  assert.equal(parseApkInfo({ ...metadata, versionCode: 0 }), null);
  assert.equal(parseApkInfo({ ...metadata, minSdk: 22 }), null);
  assert.equal(parseApkInfo({ ...metadata, targetSdk: 23 }), null);
  assert.equal(androidRequirement(24), 'Android 7 or newer');
  assert.equal(androidRequirement(26), 'Android API 26 or newer');
});
test('APK size is formatted clearly for the phone download', () => {
  assert.equal(formatApkSize(5 * 1024 * 1024), '5.0 MB');
  assert.equal(formatApkSize(200 * 1024), '200 KB');
});